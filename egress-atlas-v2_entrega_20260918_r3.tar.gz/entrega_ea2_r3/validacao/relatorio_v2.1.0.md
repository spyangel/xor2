# egress-atlas v2.1.0 — Relatório de Validação (entrega r3)

**Data:** 2026-09-18 · **Escopo:** pipeline online/offline (Bad Samurai) no `scan_v2.sh` + novo módulo `agents/prepare_targets.py`

---

## 1. O que mudou na 2.1.0

| Item | Descrição |
|---|---|
| `agents/prepare_targets.py` (novo) | Subcomandos `fetch` (online), `process` (normaliza/filtra/deduplica) e `triage` (conectividade DNS + HTTP 2xx). |
| `agents/scan_v2.sh` (reescrito) | Orquestrador fino: modo `online` (download das listas oficiais do Bad Samurai) e `offline` (uma ou mais listas locais, ou `*.txt` do diretório corrente). |
| Filtro de não-websites | Remoção por motivo: e-mail, extensão de arquivo (EXT_BLACKLIST), entrada inválida, schema não-HTTP e duplicado. |
| Triage | Só segue para analyze/test/beacon/report quem responde **HTTP 2xx** após DNS resolvido. |
| Bug de design `.com` | EXT_BLACKLIST derrubava **todo site .com** (o TLD mais comum do mundo entrava como "extensão DOS"). Corrigido e coberto por teste de regressão. |
| Fix UX offline | Diretório OUT já existente deixou de ser confundido com lista (rerun seguro). |
| Fallback `.md` no fetch | No repositório oficial, `risky-devtools` é `.md`; agora tenta `.txt` e, em 404, `.md` → 15/15 listas baixadas. |

## 2. Validação executada

### 2.1 Suíte unitária do projeto
- `ea2_unit_test.py` → **71 ok / 0 falhas**

### 2.2 Suíte do prepare_targets (nova, 24 testes)
- `test_prepare_targets.py` → **24 ok / 0 falhas**

Cobertura: wildcards (`.foo.net/`, `*.example.com/path`), formato adblock (`||host^`), scheme (https/ftp), e-mail e userinfo, extensões (exe/zip/cfg), TLDs reais mantidos (.com/.io/.tv), entradas inválidas (sem ponto, underscore, porta fora de faixa, espaço), IPv4 com porta, deduplicação e **triage real** (200 local, porta fechada → `conexao`, `.invalid` → `dns`).

### 2.3 E2E offline (3 sites: 2×200 + 1×404)
| Etapa | Resultado |
|---|---|
| process | 3 mantidas, 0 removidas |
| triage | 3 triados → 2 `ok` (200), 1 `http` (404) |
| sites_200.txt | example.com + httpbin.org/anything |
| analyze → test | 2 sites → 3 CONFIRMADOS |
| beacon | `http://httpbin.org/anything` (POST): **CONFIRMADO** |
| report | json/md/csv gerados · exit 0 |

### 2.4 E2E online real (Bad Samurai)
| Etapa | Resultado |
|---|---|
| fetch | **15/15 listas** (risky-devtools via fallback .md, 21 linhas) |
| process | 885 hostnames mantidos; removidos: 17 extensão, 14 inválido, 3 duplicado |
| triage | 20 triados → 15 `ok`, 4 `http`, 1 `dns` |
| analyze → test | 15 sites → 31 CONFIRMADOS, 1 PROVÁVEL |
| beacon | 10/10 canais CONFIRMADO |
| report | json/md/csv gerados · exit 0 |

### 2.5 Rerun offline (OUT já existente)
- Heurística corrigida: diretório existente tratado como saída, não como lista → rerun completo exit 0.

## 3. Arquivos de evidência
- `e2e_offline/` → `preparacao.json`, `triagem.json`, `sites_200.txt`, `beacon.json`
- `e2e_online/` → `preparacao.json`, `triagem.json`, `sites_200.txt`, `beacon.json`, `bs_cru_amostra.txt`

## 4. Uso

```bash
# OFFLINE: uma ou mais listas locais (ou *.txt do diretório corrente)
./agents/scan_v2.sh offline [lista1.txt lista2.txt ...] [OUT]

# ONLINE: baixa as listas do Bad Samurai e roda o pipeline
./agents/scan_v2.sh online [OUT]

# Variáveis úteis: TRIAGE_MAX, TRIAGE_CONC, TRIAGE_TIMEOUT, CONTEXT_MAX,
# TOTAL_MAX, BEACON_CYCLES, BEACON_INTERVAL, CONC, BS_LISTS
```

> Nota: a triagem considera acessível todo site com **status final HTTP 2xx (redirects seguidos)** após resolução DNS. O pipeline contextual (analyze/test/beacon/report) roda **somente** sobre os sites HTTP 200.