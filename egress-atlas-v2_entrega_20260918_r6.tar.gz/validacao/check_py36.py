#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Valida que todos os módulos do egress-atlas v2 usam apenas sintaxe Python 3.6.

Funciona de qualquer um destes lugares:
    python3 validacao/check_py36.py                 # raiz do pacote (irmãos: egress-atlas-v2/ e validacao/)
    python3 ../validacao/check_py36.py              # de dentro de egress-atlas-v2/
    python3 validacao/check_py36.py /caminho/do/egress-atlas-v2   # raiz explícita

Saída esperada: 9/9 arquivos OK. Qualquer FAIL indica sintaxe 3.7+ (walrus,
f-string "=", future import, etc.) que precisa de ajuste.
"""
import ast
import sys
import pathlib

FILES = [
    "egress_atlas_v2/__init__.py",
    "egress_atlas_v2/cli.py",
    "egress_atlas_v2/contextual.py",
    "egress_atlas_v2/abuse.py",
    "egress_atlas_v2/utils.py",
    "egress_atlas_v2/detections.py",
    "egress_atlas_v2/proxy.py",
    "egress_atlas_v2/report.py",
    "agents/prepare_targets.py",
]

def _find_root(given):
    """Resolve o diretório raiz do projeto (onde ficam egress_atlas_v2/ e agents/)."""
    if given:
        p = pathlib.Path(given)
        return p if (p / FILES[0]).exists() else p / "egress-atlas-v2"
    here = pathlib.Path(".")
    if (here / FILES[0]).exists():
        return here
    cand = here / "egress-atlas-v2"
    return cand if (cand / FILES[0]).exists() else here

def main() -> int:
    root = _find_root(sys.argv[1] if len(sys.argv) > 1 else None)
    if not (root / FILES[0]).exists():
        print(f"ERRO: não achei {FILES[0]} sob {root.resolve()}")
        print("Rode a partir da raiz do pacote ou passe o caminho como argumento.")
        return 2
    print(f"Raiz: {root.resolve()}")
    fails = []
    for rel in FILES:
        p = root / rel
        src = p.read_text(encoding="utf-8")
        try:
            ast.parse(src, filename=str(p), feature_version=(3, 6))
            print(f"OK  3.6  {rel}")
        except SyntaxError as exc:
            fails.append((rel, exc))
            print(f"FAIL 3.6  {rel}: {exc}")
    if fails:
        print(f"\n{len(fails)} arquivo(s) incompatível(is) com Python 3.6")
        return 1
    print("\nTodos os arquivos são compatíveis com a gramática Python 3.6")
    return 0

if __name__ == "__main__":
    sys.exit(main())