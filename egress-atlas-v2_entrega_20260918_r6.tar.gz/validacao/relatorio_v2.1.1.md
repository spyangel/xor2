# Relatório de validação — egress-atlas v2.1.1 (pacote completo r6)

**Data:** 2026-09-18
**Escopo:** pacote COMPLETO (fonte integral + validação), não um diff de revisão.
**Ambiente do usuário confirmado:** Python **3.6.8** — todas as validações desta
release foram feitas contra a gramática/API do 3.6.
**Motivo da release:** `SyntaxError: future feature annotations is not defined` em
`agents/prepare_targets.py:23` em Python < 3.7 (reportado pelo usuário; o
`from __future__ import annotations` é um recurso do Python 3.7+).

## Mudanças nesta revisão

1. **Remoção dos 8 `from __future__ import annotations`** (recurso 3.7+):
   `egress_atlas_v2/{__init__,cli,contextual,abuse,utils,detections,proxy,report}.py`
   e `agents/prepare_targets.py`.
2. **Generics 3.9+ em posições avaliadas em runtime → `typing.List`:**
   - `cli.py:51` — `def _read_urls(path: str) -> List[str]:`
   - `abuse.py:387` — `run_context_tests(...) -> List[AbuseFinding]`
   - `abuse.py:421` — `summarize_findings(findings: List[AbuseFinding]) -> dict`
   - `contextual.py:127,142,151,170` — `detect_* / ... -> List[str]`
   - `contextual.py:355` — `run_contextual_analysis(urls: List[str], ...) -> List[ContextProbe]`
   - `contextual.py:385` — `summarize_context(results: List[ContextProbe]) -> dict`
   - `detections.py:131` — `page_hints(body: str) -> List[str]`
   - Sem o future import, anotações de assinatura são avaliadas na definição da
     função; `list[...]` nativo só existe no 3.9+. Anotações **locais** de variável
     (ex.: `per_ctx: dict[str, int] = {}` em cli.py) nunca são avaliadas em runtime
     e permanecem inalteradas.
3. **`proxy.py` — `subprocess.check_output(..., text=True)` → `universal_newlines=True`**
   (o parâmetro `text` é 3.7+; comportamento idêntico no 3.6).
4. **`requirements.txt` compatível com 3.6:**
   - `requests>=2.26.0` (2.28+ exige Python ≥3.7 — pip não resolveria no 3.6)
   - `dataclasses; python_version < "3.7"` (backport PyPI; stdlib só no 3.7+ —
     usado por `abuse.py` e `contextual.py`)
   - `websocket-client` e `cryptography` marcados `python_version >= "3.7"`
     (não são importados por nenhum módulo; permanecem opcionais)
   - `requests-ntlm2` mantido (importado sob demanda, dentro de try/except, em proxy.py)
5. **Bump de versão:** 2.1.0 → 2.1.1 (`__init__.py`, `prepare_targets.py` + UA).
6. **Novo utilitário:** `validacao/check_py36.py` — valida a gramática 3.6 de todos
   os arquivos (ast.parse com feature_version=(3,6)).

## Validações executadas (esta revisão)

| # | Verificação | Resultado |
|---|---|---|
| 1 | Gramática Python 3.6 (ast feature_version 3.6) nos 9 arquivos | 9/9 OK |
| 2 | `py_compile` de todos os módulos (venv 3.13) | OK |
| 3 | Import smoke de todos os módulos com anotações avaliadas (eager) | 9/9 OK, sem NameError |
| 4 | `typing.List` resolvido em runtime nas 4 assinaturas-chave | OK |
| 5 | Suíte do projeto `ea2_unit_test.py` | **71 ok / 0 falhas** |
| 6 | Suíte do preparador `test_prepare_targets.py` | **24 ok (incl. regressão .com)** |
| 7 | E2E offline completo via `scan_v2.sh offline` (v2.1.1) | Pipeline completo OK |
| 8 | `bash -n agents/scan_v2.sh` | OK |

### E2E offline (evidência em `validacao/e2e_offline/`, gerada com v2.1.1)

Lista de entrada (5 linhas, exercita filtro + triagem + pipeline):

```
example.com
httpbin.org/anything
httpbin.org/status/404
setup.exe
fulano@exemplo.com
```

Resultado:

- `preparacao.json`: 5 entradas → **3 mantidas**, removidas `{extensao: 1, email: 1}`
- `triagem.json`: 3 triados (`TRIAGE_MAX=3`) → **2 ok / 1 http (404)**
- `sites_200.txt`: `example.com`, `httpbin.org/anything`
- Pipeline: análise contextual (2 sites) → testes direcionados (**3 CONFIRMADOS**,
  7 total) → beaconing curto (**1/1 CONFIRMADO**, POST httpbin.org/anything) →
  relatórios JSON/MD/CSV gerados
- Arquivos: `preparacao.json`, `triagem.json`, `sites_200.txt`, `beacon.json`,
  `context.json`, `findings.json`, `relatorio.json`, `relatorio.md`

### E2E online (evidência herdada do r4, em `validacao/e2e_online/`)

Gerada em 2026-09-18 com v2.1.0 (pré-fix de compatibilidade). As mudanças do v2.1.1
são de **compatibilidade de sintaxe/biblioteca, sem alteração de comportamento**
(remoção de future import, troca de notação de anotação, parâmetro equivalente do
subprocess, pinagens de dependência). Resultado da execução original:
15/15 listas Bad Samurai baixadas (885 mantidos; removidos {extensao:17, invalido:2,
duplicado:3}), TRIAGE_MAX=30 → 23 ok, 31 CONFIRMADOS, beacon 10/10 CONFIRMADO.

## Como reproduzir no seu ambiente

```bash
cd egress-atlas-v2
python3 --version                       # confirma 3.6+
.venv/bin/python ../validacao/check_py36.py   # 9/9 OK
.venv/bin/python ../validacao/ea2_unit_test.py -v              # 71 testes
.venv/bin/python ../validacao/test_prepare_targets.py -v       # 24 testes
TRIAGE_MAX=3 BEACON_CYCLES=2 BEACON_INTERVAL=1 \
  ./agents/scan_v2.sh offline sites_teste.txt saida_smoke
```

## Observações

- Execuções de validação feitas em sandbox Linux (Python 3.13 no venv do projeto,
  gramática 3.6 verificada via `ast.parse(feature_version=(3,6))` + ausência de
  APIs 3.7+: sem `capture_output`, `nullcontext`, walrus, etc.).
- Se o seu `python3 --version` retornar 2.7, o pacote NÃO funciona (f-strings,
  dataclasses, f-strings em todo o código) — nesse caso informe para avaliarmos
  um backport maior.
