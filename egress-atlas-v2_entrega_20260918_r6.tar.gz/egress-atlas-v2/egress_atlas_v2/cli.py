#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI do egress-atlas v2 — pipeline contextual e conclusivo.

Subcomandos:
  analyze  — análise contextual prévia dos sites (1 req/site, 100 threads)
  test     — testes direcionados por contexto (só nos sites com potencial)
  beacon   — beaconing curto nos canais CONFIRMADOS
  report   — consolida vereditos (JSON/MD/CSV)
  full     — pipeline completo: analyze → test → beacon → report

Exemplos:
  python3 -m egress_atlas_v2.cli analyze --list sites.txt -o results/context.json
  python3 -m egress_atlas_v2.cli test -f results/context.json -o results/findings.json
  python3 -m egress_atlas_v2.cli full --list sites.txt -o results
"""

import argparse
import json
import os
import platform
import sys
from typing import List

from . import __version__, utils

DEFAULTS = {
    "network": {"concurrency": 60, "timeout": 8, "verify_tls": False},
    "proxy": {"url": "", "username": "", "password": ""},
    "test": {"max_sites_per_context": 15, "max_total_sites": 80},
    "beacon": {"cycles": 3, "interval": 3.0, "max_sites": 10},
    "report": {"output_dir": "results", "assessment_name": "Egresso WebProxy v2",
               "analyst": "Dan"},
}


def _load_cfg() -> dict:
    p = os.environ.get("EGRESS_ATLAS_CONFIG") or "config.yaml"
    if os.path.exists(p):
        try:
            import yaml
            merged = json.loads(json.dumps(DEFAULTS))
            user = yaml.safe_load(open(p, encoding="utf-8")) or {}
            merged.update(user)
            return merged
        except Exception:
            pass
    return json.loads(json.dumps(DEFAULTS))


def _read_urls(path: str) -> List[str]:
    out = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                out.append(utils.normalize_url(line))
    return out


def _progress(label: str) -> None:
    print(f"[*] {label}", flush=True)


def _session(conf: dict):
    from .proxy import ProxyProfile, ProxySession, set_active_session
    prof = ProxyProfile(
        url=conf.get("proxy", {}).get("url", ""),
        username=conf.get("proxy", {}).get("username", ""),
        password=conf.get("proxy", {}).get("password", ""),
        verify_tls=conf.get("network", {}).get("verify_tls", False),
    )
    sess = ProxySession(prof,
                        pool_size=conf.get("network", {}).get("concurrency", 60))
    set_active_session(sess)
    return sess


def cmd_analyze(args, conf) -> int:
    from .contextual import run_contextual_analysis, summarize_context
    urls = _read_urls(args.list) if args.list else args.urls
    if not urls:
        print("[-] nenhuma URL", file=sys.stderr)
        return 2
    print(f"[*] análise contextual de {len(urls)} URLs "
          f"(concurrency={conf['network']['concurrency']})")
    res = run_contextual_analysis(
        urls,
        concurrency=args.concurrency or conf["network"]["concurrency"],
        timeout=args.timeout or conf["network"]["timeout"],
        progress=_progress)
    payload = {
        "summary": summarize_context(res),
        "sites": [p.to_dict() for p in res],
    }
    utils.save_json(args.out, payload)
    print(json.dumps(payload["summary"], ensure_ascii=False, indent=2))
    print(f"[+] salvo em {args.out}")
    return 0


def _select_testable(context_data: dict, conf: dict, context_filter: str = "") -> list:
    """Seleciona os sites que vão para testes, limitado por contexto."""
    from .contextual import _probe_context_one  # reuso da normalização
    from .abuse import CONTEXT_TESTS
    sites = []
    per_ctx: dict[str, int] = {}
    max_per = conf["test"].get("max_sites_per_context", 15)
    max_total = conf["test"].get("max_total_sites", 80)

    priority = {"API_REST": 1, "UPLOAD": 2, "DOWNLOAD": 3, "WEBSOCKET": 4,
                "PORTAL": 5, "ECOMMERCE": 6, "CMS": 7, "FORMULARY": 8,
                "SPA": 9, "REDIRECT": 10, "CDN_STATIC": 11, "STATIC": 12,
                "BLOCKED": 99}

    ordered = sorted(context_data.get("sites", []),
                     key=lambda s: priority.get(s.get("category", "STATIC"), 99))

    for p in ordered:
        if len(sites) >= max_total:
            break
        ctx = p.get("category", "STATIC")
        if context_filter and ctx != context_filter:
            continue
        if ctx == "BLOCKED" or not CONTEXT_TESTS.get(ctx):
            continue
        if per_ctx.get(ctx, 0) >= max_per:
            continue
        per_ctx[ctx] = per_ctx.get(ctx, 0) + 1
        sites.append(p)
    return sites


def cmd_test(args, conf) -> int:
    from .abuse import run_context_tests, summarize_findings
    # limites podem vir de env (orquestrador) ou config
    for envk, cfgk in (("EGRESS_TEST_MAX_CONTEXT", "max_sites_per_context"),
                       ("EGRESS_TEST_MAX_TOTAL", "max_total_sites")):
        v = os.environ.get(envk)
        if v:
            try:
                conf["test"][cfgk] = int(v)
            except ValueError:
                pass
    ctx = utils.load_json(args.fp)
    selected = _select_testable(ctx, conf, args.context or "")
    print(f"[*] testes direcionados em {len(selected)} sites "
          f"(por contexto, não bateria genérica)")
    from .contextual import ContextProbe
    findings = []
    seen_sites = set()
    for i, p in enumerate(selected):
        site = p.get("url")
        if site in seen_sites:
            continue
        seen_sites.add(site)
        # JSON serializado → objeto tipado (run_context_tests usa atributos)
        try:
            probe = ContextProbe(**p)
        except TypeError:
            probe = ContextProbe(url=site, category=p.get("category", "STATIC"),
                                 download_urls=p.get("download_urls", []))
        fs = run_context_tests(probe, timeout=conf["network"]["timeout"])
        for f in fs:
            f.context = p.get("category", "?")
            f.site = site
            findings.append(f)
        if (i + 1) % 10 == 0:
            _progress(f"testes {i + 1}/{len(selected)}")
    payload = {
        "summary": summarize_findings(findings),
        "findings": [f.to_dict() for f in findings],
    }
    utils.save_json(args.out, payload)
    s = payload["summary"]
    print(f"[+] CONFIRMADOS: {s['confirmed']} | PROVÁVEIS: {s['probable']} "
          f"| total: {s['total_findings']}")
    print(f"[+] salvo em {args.out}")
    return 0


def cmd_beacon(args, conf) -> int:
    from .abuse import _probe_beacon, VERDICT_CONFIRMED
    findings = utils.load_json(args.fp)
    sites = []  # (site, método do canal confirmado)
    for f in findings.get("findings", []):
        if (f.get("verdict") == VERDICT_CONFIRMED
                and f.get("test") in ("echo_query", "post_dead_drop",
                                      "websocket_channel")
                and f.get("site") not in [s[0] for s in sites]):
            method = "POST" if f.get("test") == "post_dead_drop" else "GET"
            sites.append((f.get("site"), method))
    sites = sites[: conf["beacon"].get("max_sites", 10)]
    if not sites:
        print("[*] nenhum site CONFIRMADO elegível para beacon; pulando")
        utils.save_json(args.out, {"beacons": [], "skipped": True})
        return 0
    print(f"[*] beaconing curto em {len(sites)} sites confirmados")
    beacons = []
    for site, method in sites:
        b = _probe_beacon(site, cycles=args.cycles or conf["beacon"]["cycles"],
                          interval=args.interval or conf["beacon"]["interval"],
                          timeout=conf["network"]["timeout"], method=method)
        b.site = site
        b.context = ""
        beacons.append(b)
        _progress(f"beacon {site} ({method}): {b.verdict}")
    utils.save_json(args.out, {"beacons": [b.to_dict() for b in beacons]})
    return 0


def cmd_report(args, conf) -> int:
    from .report import build_bundle, write_report
    out_dir = args.out or conf["report"]["output_dir"]
    ctx = utils.load_json(os.path.join(out_dir, "context.json")) \
        if os.path.exists(os.path.join(out_dir, "context.json")) else {}
    findings = utils.load_json(os.path.join(out_dir, "findings.json")) \
        if os.path.exists(os.path.join(out_dir, "findings.json")) else {}
    beacons = utils.load_json(os.path.join(out_dir, "beacon.json")) \
        if os.path.exists(os.path.join(out_dir, "beacon.json")) else {}

    sess = _session(conf)
    bundle = build_bundle(
        assessment_name=args.name or conf["report"]["assessment_name"],
        analyst=conf["report"].get("analyst", "Dan"),
        hostname=platform.node(),
        os_name=f"{platform.system()} {platform.release()}",
        proxy_url=sess.profile.url,
        version=__version__,
        context=ctx,
        findings=findings,
        beacons=beacons,
    )
    paths = write_report(bundle, out_dir)
    print("[+] relatórios gerados:")
    for k, v in paths.items():
        print(f"    {k}: {v}")
    return 0


def cmd_full(args, conf) -> int:
    """Pipeline completo: analyze → test → beacon → report."""
    out_dir = args.out
    os.makedirs(out_dir, exist_ok=True)
    ctx_path = os.path.join(out_dir, "context.json")
    find_path = os.path.join(out_dir, "findings.json")
    beacon_path = os.path.join(out_dir, "beacon.json")

    args.out = ctx_path
    rc = cmd_analyze(args, conf)
    if rc:
        return rc

    args.fp = ctx_path
    args.out = find_path
    args.context = ""
    rc = cmd_test(args, conf)
    if rc:
        return rc

    args.fp = find_path
    args.out = beacon_path
    args.cycles = 0
    args.interval = 0.0
    rc = cmd_beacon(args, conf)
    if rc:
        return rc

    args.out = out_dir
    args.name = args.name
    return cmd_report(args, conf)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="egress-atlas-v2",
                                 description="Avaliação contextual de egresso")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("analyze", help="análise contextual prévia")
    p.add_argument("--list", help="arquivo de URLs")
    p.add_argument("urls", nargs="*")
    p.add_argument("-o", "--out", default="results/context.json")
    p.add_argument("--concurrency", type=int, default=0)
    p.add_argument("--timeout", type=float, default=0)
    p.set_defaults(fn=cmd_analyze)

    p = sub.add_parser("test", help="testes direcionados por contexto")
    p.add_argument("-f", "--fp", default="results/context.json")
    p.add_argument("-o", "--out", default="results/findings.json")
    p.add_argument("--context", help="filtrar por categoria (API_REST, UPLOAD, ...)")
    p.set_defaults(fn=cmd_test)

    p = sub.add_parser("beacon", help="beaconing curto em canais confirmados")
    p.add_argument("-f", "--fp", default="results/findings.json")
    p.add_argument("-o", "--out", default="results/beacon.json")
    p.add_argument("--cycles", type=int, default=0)
    p.add_argument("--interval", type=float, default=0)
    p.set_defaults(fn=cmd_beacon)

    p = sub.add_parser("report", help="consolida relatório")
    p.add_argument("-o", "--out", default="results")
    p.add_argument("-n", "--name")
    p.set_defaults(fn=cmd_report)

    p = sub.add_parser("full", help="pipeline completo")
    p.add_argument("--list", required=True)
    p.add_argument("-o", "--out", default="results")
    p.add_argument("-n", "--name")
    p.add_argument("--concurrency", type=int, default=0)
    p.add_argument("--timeout", type=float, default=0)
    p.set_defaults(fn=cmd_full)

    args = ap.parse_args(argv)
    conf = _load_cfg()
    _session(conf)
    try:
        return args.fn(args, conf)
    except KeyboardInterrupt:
        print("\n[!] interrompido")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())