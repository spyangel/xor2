# -*- coding: utf-8 -*-
"""Utils v2 — encoding, tokens, jitter, helpers."""

import base64
import os
import random
import time
from typing import Optional


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def random_token(nbytes: int = 12) -> str:
    """Token único de teste (hex). Rastreável e inofensivo."""
    return os.urandom(nbytes).hex()


def jittered_sleep(base: float, jitter: float,
                   rng: Optional[random.Random] = None) -> None:
    rng = rng or random
    time.sleep(max(0.0, rng.uniform(base * (1 - jitter), base * (1 + jitter))))


def host_of(url: str) -> str:
    try:
        from urllib.parse import urlparse
        return urlparse(url).hostname or ""
    except Exception:
        return ""


def scheme_of(url: str) -> str:
    try:
        from urllib.parse import urlparse
        return urlparse(url).scheme
    except Exception:
        return ""


def normalize_url(raw: str) -> str:
    raw = raw.strip()
    if not raw:
        return ""
    if not raw.startswith(("http://", "https://")):
        raw = "http://" + raw
    return raw


def load_json(path: str):
    import json
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: str, obj) -> None:
    import json
    import os as _os
    _os.makedirs(_os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
