# egress-atlas v2.1.2 — pacote completo (r7)

Ferramenta de **avaliação contextual de websites abusáveis via webproxy corporativo**
(perspectiva insider em desktop Windows: Defender, GPO, proxy), alimentada pelas listas
do **B'ad Samurai** (`BadSamuraiDev/bs-lists`).

Compatível com **Python 3.6+** (ambiente do usuário confirmado: **Python 3.6.8**;
release validada de ponta a ponta em Python **3.6.15 real** com locale ASCII).

## Estrutura (pacote completo — este é o projeto inteiro, não um diff)

```
egress-atlas-v2/                 ← CÓDIGO-FONTE COMPLETO
├── agents/
│   ├── scan_v2.sh               ← ORQUESTRADOR (modos online/offline)
│   └── prepare_targets.py       ← fetch (Bad Samurai) + process (filtro) + triage (HTTP 2xx)
├── egress_atlas_v2/             ← pacote Python (7 módulos; __init__.py = v2.1.2)
│   ├── cli.py                   ← CLI analyze / test / beacon / report
│   ├── contextual.py            ← classificação de contexto (API, CDN, portal…)
│   ├── abuse.py                 ← classes de abuso + testes direcionados por contexto
│   ├── detections.py            ← detecções em página (downloads, forms, hints…)
│   ├── proxy.py                 ← checagens de proxy corporativo (NTLM sob demanda)
│   ├── utils.py                 ← utilitários (threads, tolerâncias, harden_stdio)
│   └── report.py                ← relatórios JSON/MD/CSV
├── config.yaml                  ← proxy corporativo, limites por contexto
└── requirements.txt             ← 100% ASCII, pinagens compatíveis com Python 3.6
validacao/                       ← VALIDAÇÃO (suítes, checador 3.6, evidências E2E)
├── check_py36.py                ← valida a gramática 3.6 dos 9 arquivos (saída ASCII)
├── ea2_unit_test.py             ← suíte do projeto (71 testes; APIs 3.6-safe)
├── test_prepare_targets.py      ← suíte do preparador (24 testes; APIs 3.6-safe)
├── e2e_py36/                    ← E2E offline executado em Python 3.6.15 REAL (locale C)
├── e2e_offline/                 ← evidências do E2E offline (pipeline inteiro, v2.1.1)
└── e2e_online/                  ← evidências do E2E online (15 listas Bad Samurai)
LEIA-ME.md
```

## Requisitos

- **Python 3.6 ou superior** (confirmado no ambiente 3.6.8 do usuário; validado em
  3.6.15 e 3.13).
- `pip install -r requirements.txt` instala: `requests>=2.26.0` (2.28+ exige 3.7),
  `pyyaml>=6.0` e o backport `dataclasses` no 3.6 (stdlib só no 3.7+).
- Opcionais: `requests-ntlm2` (proxy NTLM, importado sob demanda; **validado no 3.6.15**),
  `websocket-client`/`cryptography` (Python ≥3.7; **não** são importados pelos módulos).

## Instalação

```bash
cd egress-atlas-v2
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

Nenhuma configuração de locale é necessária: o `requirements.txt` é 100% ASCII e os
CLIs protegem stdout/stderr (`harden_stdio`) — instalação e `--help` funcionam mesmo
com o sistema em locale C/ASCII.

Valide a compatibilidade 3.6 na sua máquina:

```bash
python3 --version                        # 3.6.8 esperado
.venv/bin/python ../validacao/check_py36.py   # 9/9 OK = sintaxe compatível 3.6
```

## Uso

```bash
# OFFLINE — uma ou mais listas locais (ou todos os *.txt do diretório corrente)
./agents/scan_v2.sh offline [lista1.txt lista2.txt ...] [OUT]

# ONLINE — baixa as 15 listas do B'ad Samurai (BadSamuraiDev/bs-lists) e roda o pipeline
./agents/scan_v2.sh online [OUT]

./agents/scan_v2.sh help     # lembrete dos modos e variáveis
```

Pipeline (sempre o mesmo após a preparação dos alvos):
**normaliza/filtra → triagem (DNS + HTTP 2xx) → analyze → test → beacon → report**
— os testes contextuais rodam somente nos sites que responderam **HTTP 200**.

## Filtro do que NÃO é website (motivos em `validacao/e2e_py36/preparacao.json` / `preparacao.json` da sua execução)

- `email` — endereço e-mail / userinfo em URL
- `extensao` — arquivo (exe, msi, zip, pdf, docx, pem, key, aws, cfg…)
- `invalido` — entrada sem TLD, underscore, porta fora de faixa, espaço…
- `nao_http` — schema ftp://, file:// etc.
- `duplicado` — repetido entre listas

> `.com` NUNCA é tratado como extensão (é TLD). Novos gTLDs abusados como `.zip`
> são tratados como extensão — decisão deliberada.

## Variáveis de ambiente

| Var | Default | Uso |
|---|---|---|
| `TRIAGE_CONC` | 100 | threads da triagem |
| `TRIAGE_TIMEOUT` | 12 | timeout por request na triagem (s) |
| `TRIAGE_MAX` | (todos) | limita nº de sites triados (smoke/testes) |
| `CONC` | 60 | threads da análise contextual |
| `CONTEXT_MAX` / `TOTAL_MAX` | 15 / 80 | limites de testes por contexto / total |
| `BEACON_CYCLES` / `BEACON_INTERVAL` | 3 / 3 | beaconing |
| `BS_LISTS` | (15 oficiais) | sobrescreve as listas do Bad Samurai |

Ex.: `TRIAGE_MAX=100 ./agents/scan_v2.sh online saida_teste`

## Validação incluída (2026-09-18 — r7)

- **E2E offline completo em Python 3.6.15 real (locale C/ASCII)**: pipeline
  process→triage→analyze→test→beacon→report VERDE — evidências em
  `validacao/e2e_py36/` (filtros corretos: setup.exe→extensao,
  fulano@exemplo.com→email, HTTP 404 rejeitado; 3 CONFIRMADOS; sem crashes Unicode)
- Sintaxe Python 3.6 (ast feature_version 3.6): **9/9 arquivos** (`check_py36.py`)
- Suíte do projeto (`ea2_unit_test.py`): **71 ok / 0 falhas** (3.6.15 e 3.13)
- Suíte do preparador (`test_prepare_targets.py`): **24 ok / 0 falhas** (3.6.15 e 3.13)
- `pip install -r requirements.txt` sob locale ASCII no 3.6.15: OK
- `--help` dos CLIs em locale C: OK (sem UnicodeEncodeError)
- E2E offline (v2.1.1): `validacao/e2e_offline/` · E2E online (15 listas):
  `validacao/e2e_online/`
- `bash -n agents/scan_v2.sh`: OK · md5 das fontes: idênticas ao projeto

## Histórico de versões

- **2.1.2 (atual)** — compat Python 3.6+ (2ª rodada de hardening, validado em 3.6.15
  real): `argparse` sem `required=True` nos subparsers (`prepare_targets.py`),
  `harden_stdio()` nos CLIs (fim do `UnicodeEncodeError` em locale ASCII),
  `requirements.txt` reescrito 100% ASCII (fim do erro de pip em locale ASCII),
  harnesses de teste convertidos para APIs 3.6 (`ThreadingHTTPServer` shim,
  `universal_newlines`, handler sem kwarg `directory`, `encoding="utf-8"` nos
  `open()`), `check_py36.py` com saída ASCII.
- **2.1.1** — compat Python 3.6+: remoção dos 8 `from __future__ import annotations`
  (recurso 3.7+), `list[...]` → `typing.List` nas assinaturas, `text=True` →
  `universal_newlines=True` em proxy.py, requirements.txt repineado.
- **2.1.0** — pipeline Bad Samurai online/offline (`prepare_targets.py` fetch/process/triage;
  `scan_v2.sh` modos `online`/`offline`).
- **2.0.2** — correção de path relativo em `scan_v2.sh` (INVOKE_DIR + SCRIPT_DIR).