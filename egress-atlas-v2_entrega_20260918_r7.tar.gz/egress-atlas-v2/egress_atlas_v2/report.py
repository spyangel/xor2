# -*- coding: utf-8 -*-
"""Relatório v2 — foco em vereditos conclusivos e prioridade de ação.

Formato: JSON (completo) + Markdown executivo (top achados, tabela de
vereditos, recomendação de ação) + CSV (linha por achado).
"""

import csv
import json
import os
from datetime import datetime


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def build_bundle(assessment_name, analyst, hostname, os_name, proxy_url,
                 version, context, findings, beacons) -> dict:
    return {
        "meta": {
            "assessment_name": assessment_name,
            "generated_at": _now(),
            "analyst": analyst,
            "hostname": hostname,
            "os": os_name,
            "proxy": proxy_url,
            "version": version,
        },
        "context": context,
        "findings": findings,
        "beacons": beacons,
    }


def _confirmed(findings: list) -> list:
    return [f for f in findings if f.get("verdict") == "CONFIRMADO"]


def _probable(findings: list) -> list:
    return [f for f in findings if f.get("verdict") == "PROVAVEL"]


def build_markdown(bundle: dict) -> str:
    meta = bundle.get("meta", {})
    ctx = bundle.get("context", {})
    findings = bundle.get("findings", {}).get("findings", [])
    beacons = bundle.get("beacons", {}).get("beacons", [])
    conf = _confirmed(findings)
    prob = _probable(findings)

    L = []
    L.append(f"# {meta.get('assessment_name', 'Avaliação de Egresso v2')}")
    L.append("")
    L.append(f"- **Data:** {meta.get('generated_at', _now())}")
    L.append(f"- **Analista:** {meta.get('analyst', '')}")
    L.append(f"- **Host:** {meta.get('hostname', '')} ({meta.get('os', '')})")
    L.append(f"- **Proxy:** {meta.get('proxy', '') or '(direto)'}")
    L.append("")

    # 1. Contexto
    L.append("## 1. Análise contextual (triagem)")
    L.append("")
    s = ctx.get("summary", {})
    L.append(f"- Sites analisados: **{s.get('total', 0)}**")
    cats = s.get("by_category", {})
    if cats:
        L.append("- Distribuição:")
        for c, n in sorted(cats.items(), key=lambda x: -x[1]):
            L.append(f"  - {c}: {n}")
    techs = s.get("by_technology", {})
    if techs:
        L.append("- Tecnologias mais comuns: "
                 + ", ".join(f"{k} ({v})" for k, v in
                             sorted(techs.items(), key=lambda x: -x[1])[:8]))
    L.append(f"- Sites com downloads: {s.get('sites_with_downloads', 0)} | "
             f"sites com formulários: {s.get('sites_with_forms', 0)}")
    L.append("")

    # 2. Vereditos
    L.append("## 2. Vereditos conclusivos")
    L.append("")
    L.append(f"- **CONFIRMADOS:** {len(conf)}")
    L.append(f"- **PROVÁVEIS (confirmar manualmente):** {len(prob)}")
    L.append("")
    if conf:
        L.append("### 2.1 Achados CONFIRMADOS (evidência objetiva)")
        L.append("")
        L.append("| Site | Contexto | Teste | Risco | Evidência |")
        L.append("|---|---|---|---|---|")
        for f in sorted(conf, key=lambda x: -x.get("risk", 0)):
            L.append(f"| {f.get('site')} | {f.get('context')} | {f.get('test')} "
                     f"| {f.get('risk')}/3 | "
                     f"{(f.get('evidence') or '')[:150].replace('|', '/')} |")
        L.append("")
    if prob:
        L.append("### 2.2 Prováveis (exigem confirmação manual)")
        L.append("")
        L.append("| Site | Contexto | Teste | Risco | Evidência |")
        L.append("|---|---|---|---|---|")
        for f in sorted(prob, key=lambda x: -x.get("risk", 0)):
            L.append(f"| {f.get('site')} | {f.get('context')} | {f.get('test')} "
                     f"| {f.get('risk')}/3 | "
                     f"{(f.get('evidence') or '')[:150].replace('|', '/')} |")
        L.append("")

    # 3. Instaladores
    installers = [f for f in findings
                  if f.get("test") == "installer_download"
                  and f.get("verdict") == "CONFIRMADO"]
    if installers:
        L.append("## 3. Instaladores baixáveis via proxy (VPN/remoto)")
        L.append("")
        L.append("| Site | Arquivo | Tipo | Risco |")
        L.append("|---|---|---|---|")
        for f in sorted(installers, key=lambda x: -x.get("risk", 0)):
            d = f.get("detail", {})
            L.append(f"| {f.get('site')} | {d.get('filename', '?')} | "
                     f"{d.get('kind', '?')} | {f.get('risk')}/3 |")
        L.append("")
        L.append("**Atenção:** clientes VPN/túnel baixáveis pela allowlist "
                 "permitem a um atacante interno criar túnel fora da política. "
                 "Recomenda-se bloquear a categoria de download desses "
                 "binários ou adicionar exceção de inspeção.")
        L.append("")

    # 4. Beacon
    if beacons:
        L.append("## 4. Estabilidade de beacon (canais confirmados)")
        L.append("")
        L.append("| Site | Veredito | Evidência |")
        L.append("|---|---|---|")
        for b in beacons:
            L.append(f"| {b.get('site')} | {b.get('verdict')} | "
                     f"{(b.get('evidence') or '')[:120]} |")
        L.append("")

    # 5. Recomendações
    L.append("## 5. Recomendações de ação (blue team)")
    L.append("")
    L.append("1. **Bloquear downloads de clientes VPN/túnel** (seção 3) na "
             "política do proxy — maior alavanca contra tunelamento.")
    L.append("2. **Correlacionar egresso por método+corpo:** sites com dead "
             "drop confirmado merecem regra de bloqueio de POST ou alerta de "
             "volume.")
    L.append("3. **Monitorar reflexão:** sites com echo confirmado permitem "
             "exfiltração com confirmação — alertar em consultas com "
             "parâmetros longos/base64.")
    L.append("4. **Beaconing:** sites com beacon estável merecem alerta de "
             "frequência regular (mesmo host, mesmo caminho, horário fixo).")
    L.append("5. **Revisar CORS aberto** em sites corporativos — permite "
             "leitura cross-origin por página maliciosa.")
    L.append("")
    L.append("---")
    L.append(f"*Gerado por egress-atlas v{meta.get('version', '?')}*")
    return "\n".join(L)


def write_report(bundle: dict, out_dir: str, prefix: str = "egress_v2") -> dict:
    os.makedirs(out_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.join(out_dir, f"{prefix}_{ts}")
    paths = {}
    with open(base + ".json", "w", encoding="utf-8") as f:
        json.dump(bundle, f, ensure_ascii=False, indent=2)
    paths["json"] = base + ".json"
    with open(base + ".md", "w", encoding="utf-8") as f:
        f.write(build_markdown(bundle))
    paths["md"] = base + ".md"

    # CSV de achados
    findings = bundle.get("findings", {}).get("findings", [])
    if findings:
        with open(base + "_achados.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["site", "contexto", "teste", "veredito", "risco",
                        "evidencia", "detalhe"])
            for x in sorted(findings, key=lambda r: -r.get("risk", 0)):
                w.writerow([
                    x.get("site", ""), x.get("context", ""), x.get("test", ""),
                    x.get("verdict", ""), x.get("risk", 0),
                    (x.get("evidence") or "").replace("\n", " "),
                    json.dumps(x.get("detail", {}), ensure_ascii=False),
                ])
        paths["csv"] = base + "_achados.csv"

    # CSV resumo por site (para tomada de decisão)
    sites = {}
    for x in findings:
        s = sites.setdefault(x.get("site", ""), {
            "site": x.get("site", ""), "contexto": x.get("context", ""),
            "confirmados": [], "prováveis": [], "risco_max": 0})
        if x.get("verdict") == "CONFIRMADO":
            s["confirmados"].append(x.get("test", ""))
        elif x.get("verdict") == "PROVAVEL":
            s["prováveis"].append(x.get("test", ""))
        s["risco_max"] = max(s["risco_max"], x.get("risk", 0))
    if sites:
        with open(base + "_sites.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["site", "contexto", "risco_max", "confirmados",
                        "prováveis"])
            for s in sorted(sites.values(), key=lambda r: -r["risco_max"]):
                w.writerow([s["site"], s["contexto"], s["risco_max"],
                            ";".join(s["confirmados"]),
                            ";".join(s["prováveis"])])
        paths["csv_sites"] = base + "_sites.csv"
    return paths
