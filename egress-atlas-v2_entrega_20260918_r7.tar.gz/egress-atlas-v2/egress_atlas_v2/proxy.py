# -*- coding: utf-8 -*-
"""Transporte via webproxy (v2 — com pool, retry e limpeza de sessão)."""

import os
import re
import subprocess
import time
from typing import Optional

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ProxyProfile:
    def __init__(self, url: str = "", username: str = "", password: str = "",
                 verify_tls: bool = False):
        self.url = url or self.discover_from_env()
        self.username = username
        self.password = password
        self.verify_tls = verify_tls

    @staticmethod
    def discover_from_env() -> str:
        for var in ("HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy",
                    "ALL_PROXY", "all_proxy"):
            v = os.environ.get(var)
            if v:
                return v
        if os.name == "nt":
            try:
                out = subprocess.check_output(
                    ["netsh", "winhttp", "show", "proxy"],
                    stderr=subprocess.DEVNULL, universal_newlines=True)
                m = re.search(r"Proxy Server\(s\)\s*:\s*(\S+)", out)
                if m and m.group(1) not in ("(direct)", ""):
                    return "http://" + m.group(1)
            except Exception:
                pass
        return ""

    def proxies_dict(self) -> dict:
        if not self.url:
            return {}
        return {"http": self.url, "https": self.url}

    def auth_hooks(self) -> list:
        hooks = []
        if not self.username:
            return hooks
        try:
            from requests_ntlm import HttpNtlmAuth
            domain = ""
            user = self.username
            if "\\" in user:
                domain, user = user.split("\\", 1)
            hooks.append(HttpNtlmAuth(domain + "\\" + user, self.password))
        except ImportError:
            pass
        if not hooks:
            from requests.auth import HTTPProxyAuth
            hooks.append(HTTPProxyAuth(self.username, self.password))
        return hooks

    def __repr__(self) -> str:
        return f"ProxyProfile(url={self.url!r})"


class ProxySession:
    def __init__(self, profile: Optional[ProxyProfile] = None,
                 max_retries: int = 1, pool_size: int = 100):
        self.profile = profile or ProxyProfile()
        self.session = requests.Session()
        self.session.trust_env = False if self.profile.url else True
        if self.profile.url:
            self.session.proxies.update(self.profile.proxies_dict())
        for hook in self.profile.auth_hooks():
            self.session.auth = hook
        self.session.headers["User-Agent"] = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        )
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=pool_size,
            pool_maxsize=pool_size,
            max_retries=requests.adapters.Retry(
                total=max_retries,
                backoff_factor=0.3,
                # sem retry por status: 5xx legítimo vira RetryError e
                # mascararia a resposta real (falso BLOCKED). Retry apenas
                # em falhas de conexão (default do Retry).
                status_forcelist=[],
                allowed_methods=None,
            ),
        )
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def request(self, method: str, url: str, allow_redirects: bool = True,
                timeout: float = 8.0, **kw):
        kw.setdefault("timeout", timeout)
        kw.setdefault("verify", self.profile.verify_tls)
        return self.session.request(method, url, allow_redirects=allow_redirects, **kw)

    def get(self, url: str, **kw):
        return self.request("GET", url, **kw)

    def post(self, url: str, **kw):
        return self.request("POST", url, **kw)


_active: Optional[ProxySession] = None


def set_active_session(sess: ProxySession) -> None:
    global _active
    _active = sess


def s() -> ProxySession:
    global _active
    if _active is None:
        _active = ProxySession()
    return _active