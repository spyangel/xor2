# -*- coding: utf-8 -*-
"""Heurísticas de alto valor: classificação de instaladores e padrões de abuso.

Foco do cenário: ameaça interna em desktop Windows gerenciado (Defender, GPO,
webproxy). O que interessa:

1. INSTALADORES DE VPN / ACESSO REMOTO — um atacante interno pode baixar um
   cliente VPN legítimo pela allowlist e criar túnel fora da política
   (split tunnel, rede externa, bypass de inspeção).
2. FERRAMENTAS DE ACESSO REMOTO (AnyDesk, TeamViewer, RustDesk...) — controle
   remoto não autorizado.
3. BINÁRIOS ASSINADOS / PORTÁTEIS — execução sem instalação (Defender pode
   permitir assinados).
4. ARQUIVOS DE EXFIL (ZIP/RAR) — volumes grandes disfarçados.
"""

import re
from typing import List

# (marca no nome/URL, nome amigável, risco) — risco: 3=crítico (túnel direto),
# 2=alto (acesso remoto), 1=médio (ferramenta de utilidade)
INSTALLER_SIGNATURES = [
    # --- clientes VPN / túnel -------------------------------------------
    (r"openvpn", "OpenVPN client", 3),
    (r"wireguard", "WireGuard", 3),
    (r"tailscale", "Tailscale", 3),
    (r"zerotier", "ZeroTier", 3),
    (r"softether", "SoftEther VPN", 3),
    (r"nordvpn", "NordVPN", 3),
    (r"expressvpn", "ExpressVPN", 3),
    (r"surfshark", "Surfshark", 3),
    (r"protonvpn", "Proton VPN", 3),
    (r"cisco.*(anyconnect|secure client)", "Cisco AnyConnect/Secure Client", 3),
    (r"globalprotect", "Palo Alto GlobalProtect", 3),
    (r"forticlient", "FortiClient VPN", 3),
    (r"fortinet", "Fortinet VPN", 3),
    (r"pulse.*secure", "Pulse Secure", 3),
    (r"ivanti", "Ivanti (Pulse) Connect", 3),
    (r"ncp.*secure.*entry", "NCP Secure Entry", 3),
    (r"vpn", "Cliente VPN genérico", 3),
    # --- acesso remoto ----------------------------------------------------
    (r"anydesk", "AnyDesk", 2),
    (r"teamviewer", "TeamViewer", 2),
    (r"rustdesk", "RustDesk", 2),
    (r"parsec", "Parsec", 2),
    (r"chrome.*remote", "Chrome Remote Desktop", 2),
    (r"screenconnect", "ScreenConnect", 2),
    (r"gotoassist", "GoToAssist", 2),
    (r"ultraviewer", "UltraViewer", 2),
    (r"ammyy", "Ammyy Admin", 2),
    (r"remote.*desktop", "Remote Desktop utility", 2),
    # --- tunelamento / proxy ---------------------------------------------
    (r"ngrok", "ngrok", 3),
    (r"cloudflared", "cloudflared (túnel Cloudflare)", 3),
    (r"frp(\.exe|_|-)", "frp (Fast Reverse Proxy)", 3),
    (r"chisel", "Chisel tunnel", 3),
    (r"stunnel", "stunnel", 3),
    (r"ssh", "SSH client", 2),
    (r"putty", "PuTTY (SSH/túnel)", 2),
    # --- utilitários de exfil -------------------------------------------------
    (r"7zip|7z[0-9]{2}", "7-Zip", 1),
    (r"winrar", "WinRAR", 1),
    (r"bandizip", "Bandizip", 1),
    (r"rar", "WinRAR/rar", 1),
    # --- ferramentas de pós-exploração -------------------------------------
    (r"nmap", "nmap", 2),
    (r"wireshark", "Wireshark", 2),
    (r"ncat|netcat", "netcat", 2),
    (r"proxychains", "proxychains", 2),
]

FILE_EXT_RISK = {
    ".exe": 2, ".msi": 3, ".zip": 2, ".rar": 2, ".7z": 2, ".dmg": 1,
    ".pkg": 1, ".apk": 1, ".bat": 2, ".ps1": 2, ".cmd": 2, ".jar": 2,
    ".iso": 2, ".bin": 1,
}


def classify_installer(filename: str, url: str = "") -> dict:
    """Classifica um nome de arquivo/URL de download.

    Retorna dict com: is_installer, kind, risk, matched, suggest.
    """
    hay = (filename + " " + url).lower()
    best = None
    for pattern, name, risk in INSTALLER_SIGNATURES:
        if re.search(pattern, hay, re.I):
            if best is None or risk > best[2]:
                best = (pattern, name, risk)
    if best:
        return {
            "is_installer": True,
            "kind": best[1],
            "risk": best[2],
            "matched": best[0],
            "suggest": (
                "baixável via allowlist — avaliar bloqueio por categoria"
                if best[2] >= 2 else
                "utilitário — risco condicional ao uso"),
        }
    # fallback por extensão
    ext = re.search(r"\.([a-z0-9]{2,4})$", filename.lower())
    if ext:
        e = "." + ext.group(1)
        if e in FILE_EXT_RISK and FILE_EXT_RISK[e] >= 2:
            return {
                "is_installer": True,
                "kind": f"arquivo {e}",
                "risk": FILE_EXT_RISK[e],
                "matched": e,
                "suggest": "extensão executável/empacotada baixável",
            }
    return {"is_installer": False, "kind": "", "risk": 0, "matched": "",
            "suggest": ""}


# Palavras-chave de página (para contexto da nota)
PAGE_HINTS = {
    "login": ("login form", 1),
    "sign in": ("login form", 1),
    "intranet": ("intranet", 2),
    "portal": ("portal", 2),
    "dashboard": ("dashboard", 1),
    "upload": ("upload disponível", 2),
    "download": ("download disponível", 1),
    "api": ("API surface", 2),
    "status": ("status/health", 1),
    "admin": ("área administrativa", 2),
}


def page_hints(body: str) -> List[str]:
    """Extrai indícios de função da página a partir do corpo (baixo custo)."""
    out = []
    body_l = body.lower()
    for kw, (label, _) in PAGE_HINTS.items():
        if kw in body_l and label not in out:
            out.append(label)
    return out
