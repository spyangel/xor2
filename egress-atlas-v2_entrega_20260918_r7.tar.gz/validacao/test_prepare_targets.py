#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Testes unitários do prepare_targets.py (v2.1) — process + triage."""
import io
import json
import os
import posixpath
import subprocess
import sys
import threading
import unittest
import urllib.parse
from http.server import SimpleHTTPRequestHandler, HTTPServer

_HERE = os.path.dirname(os.path.abspath(__file__))
for _cand in ("/home/user/egress-atlas-v2/agents",
              os.path.join(_HERE, "..", "egress-atlas-v2", "agents")):
    if os.path.isdir(_cand):
        sys.path.insert(0, _cand)
        break
os.environ.setdefault("NO_PROXY", "*")
os.environ.setdefault("no_proxy", "*")

TRIAGE_PORT = 8917
TRIAGE_ROOT = "/tmp/triage_root_pt"


def _safe_stdio():
    """Garante stdout/stderr ASCII-safe em Python 3.6 (locale C/ASCII)."""
    for _s in (sys.stdout, sys.stderr):
        if _s is None:
            continue
        _rc = getattr(_s, "reconfigure", None)
        if _rc is not None:  # Python 3.7+
            try:
                _rc(errors="backslashreplace")
            except Exception:
                pass
            continue
        try:
            _enc = _s.encoding or "utf-8"
            if "utf" in _enc.lower() or "65001" in _enc:
                continue
            _buf = getattr(_s, "buffer", None)
            if _buf is None:
                continue
            _new = io.TextIOWrapper(_buf, encoding=_enc,
                                    errors="backslashreplace",
                                    line_buffering=True)
        except Exception:
            continue
        if _s is sys.stdout:
            sys.stdout = _new
        elif _s is sys.stderr:
            sys.stderr = _new


_safe_stdio()

try:
    from http.server import ThreadingHTTPServer  # Python 3.7+
except ImportError:  # Python 3.6: monta a mesma classe com ThreadingMixIn
    from socketserver import ThreadingMixIn

    class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True


class _RaizHandler(SimpleHTTPRequestHandler):
    """Serve arquivos a partir de TRIAGE_ROOT sem depender do cwd (3.6+)."""

    def translate_path(self, path):
        parts = urllib.parse.urlsplit(path)
        path = posixpath.normpath(urllib.parse.unquote(parts.path))
        words = [w for w in path.split("/") if w]
        return os.path.join(TRIAGE_ROOT, *words)


import prepare_targets as pt  # noqa: E402


class TestNormalizaToken(unittest.TestCase):
    """Filtros e normalização de tokens crus (listas BS / locais)."""

    def _tok(self, raw):
        entrada, motivo = pt._normaliza_token(raw)
        return entrada, motivo

    def test_wildcard_ponto_inicial(self):
        entrada, motivo = self._tok(".0bin.net/")
        self.assertIsNone(motivo)
        self.assertTrue(entrada.startswith("0bin.net"))

    def test_asterisco_wildcard(self):
        entrada, motivo = self._tok("*.example.com/path")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "example.com/path")

    def test_adblock_duplas_barras_e_circunflexo(self):
        entrada, motivo = self._tok("||doubleclick.net^")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "doubleclick.net")

    def test_protocol_relative(self):
        entrada, motivo = self._tok("//example.com")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "example.com")

    def test_https_com_scheme(self):
        entrada, motivo = self._tok("https://example.com/x")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "example.com/x")

    def test_email_simples(self):
        _, motivo = self._tok("foo@bar.com")
        self.assertEqual(motivo, "email")

    def test_userinfo_em_url(self):
        _, motivo = self._tok("https://admin:pw@x.com/")
        self.assertEqual(motivo, "email")

    def test_arquivo_exe(self):
        _, motivo = self._tok("arquivo.exe")
        self.assertEqual(motivo, "extensao")

    def test_arquivo_zip(self):
        _, motivo = self._tok("setup.zip")
        self.assertEqual(motivo, "extensao")

    def test_arquivo_cfg(self):
        _, motivo = self._tok("settings.cfg")
        self.assertEqual(motivo, "extensao")

    def test_tld_com_mantido(self):
        """Regressão: .com NUNCA pode ser tratado como extensão."""
        for raw in ("example.com", "www.example.com/redir/x",
                    "*.example.com", "https://example.com"):
            entrada, motivo = self._tok(raw)
            self.assertIsNone(motivo, f"{raw} -> {motivo}")
            self.assertIsNotNone(entrada)

    def test_tld_real_io_mantido(self):
        entrada, motivo = self._tok("exemplo.io")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "exemplo.io")

    def test_tld_real_tv_mantido(self):
        entrada, motivo = self._tok("canal.tv")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "canal.tv")

    def test_palavra_sem_ponto_invalida(self):
        _, motivo = self._tok("cfg")
        self.assertEqual(motivo, "invalido")

    def test_aws_sem_ponto_invalido(self):
        _, motivo = self._tok("aws")
        self.assertEqual(motivo, "invalido")

    def test_bash_history_sem_ponto_invalido(self):
        _, motivo = self._tok("bash_history")
        self.assertEqual(motivo, "invalido")

    def test_ftp_nao_http(self):
        _, motivo = self._tok("ftp://servidor.com/")
        self.assertEqual(motivo, "nao_http")

    def test_ipv4_com_porta_mantido(self):
        entrada, motivo = self._tok("127.0.0.1:8000")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "127.0.0.1:8000")

    def test_espaco_invalido(self):
        _, motivo = self._tok("https://example.com/a b")
        self.assertEqual(motivo, "invalido")

    def test_porta_invalida(self):
        _, motivo = self._tok("example.com:99999")
        self.assertEqual(motivo, "invalido")

    def test_underscore_invalido(self):
        _, motivo = self._tok("minha_casa.com")
        self.assertEqual(motivo, "invalido")

    def test_ponto_final_removido(self):
        entrada, motivo = self._tok("example.com.")
        self.assertIsNone(motivo)
        self.assertEqual(entrada, "example.com")


class TestCmdProcess(unittest.TestCase):
    """Pipeline process via CLI real (subprocess)."""

    def setUp(self):
        self.dir = "/tmp/ea2_proc_test"
        os.makedirs(self.dir, exist_ok=True)
        self.suja = os.path.join(self.dir, "suja.txt")
        with open(self.suja, "w", encoding="utf-8") as f:
            f.write(
                "# comentario ignorado\n"
                "! lista hosts\n"
                "[bloco]\n"
                "\n"
                ".0bin.net/\n"
                "*.example.com/path\n"
                "||doubleclick.net^\n"
                "foo@bar.com\n"
                "arquivo.exe\n"
                "setup.zip\n"
                "settings.cfg\n"
                "cfg\n"
                "aws\n"
                "bash_history\n"
                "ftp://servidor.com/\n"
                "https://example.com\n"
                "example.com\n"                # duplicado
                "exemplo.io\n"
                "127.0.0.1:8000\n"
            )

    def test_process_via_cli(self):
        out = os.path.join(self.dir, "limpo.txt")
        stats = os.path.join(self.dir, "stats.json")
        r = subprocess.run(
            [sys.executable, pt.__file__, "process",
             "--in", self.suja, "--out", out, "--stats", stats],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            universal_newlines=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        mantidos = [l for l in open(out, encoding="utf-8").read().splitlines() if l]
        self.assertIn("0bin.net/", mantidos)
        self.assertIn("example.com/path", mantidos)
        self.assertIn("doubleclick.net", mantidos)
        self.assertIn("example.com", mantidos)
        self.assertIn("exemplo.io", mantidos)
        self.assertIn("127.0.0.1:8000", mantidos)
        self.assertEqual(len(mantidos), len(set(mantidos)), "sem duplicados")
        st = json.load(open(stats, encoding="utf-8"))
        self.assertEqual(st["mantidas"], 6)
        self.assertEqual(st["removidas"]["email"], 1)       # apenas foo@bar.com
        self.assertEqual(st["removidas"]["extensao"], 3)    # arquivo.exe, setup.zip, settings.cfg
        self.assertEqual(st["removidas"]["invalido"], 3)    # cfg, aws, bash_history (sem ponto)
        self.assertEqual(st["removidas"]["duplicado"], 1)   # example.com repetido
        self.assertEqual(st["removidas"]["nao_http"], 1)    # ftp://
        self.assertEqual(st["entradas_nao_vazias"], 15)      # 6+1+3+3+1+1


class TestCmdTriage(unittest.TestCase):
    """Triage com http.server local (200), porta fechada (conexao) e DNS (.invalid)."""

    @classmethod
    def setUpClass(cls):
        os.makedirs(TRIAGE_ROOT, exist_ok=True)
        # _RaizHandler serve de TRIAGE_ROOT sem o kwarg directory= (3.7+)
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", TRIAGE_PORT),
                                        _RaizHandler)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def setUp(self):
        self.dir = "/tmp/ea2_triage_test"
        os.makedirs(self.dir, exist_ok=True)
        self.lista = os.path.join(self.dir, "alvos.txt")
        with open(self.lista, "w", encoding="utf-8") as f:
            f.write(f"127.0.0.1:{TRIAGE_PORT}\n")
            f.write("127.0.0.1:1\n")
            f.write("hostnaoexiste-xyz.invalid\n")

    def test_triage_via_cli(self):
        out = os.path.join(self.dir, "triagem.json")
        sites200 = os.path.join(self.dir, "sites_200.txt")
        r = subprocess.run(
            [sys.executable, pt.__file__, "triage",
             "--list", self.lista, "--out", out,
             "--sites200", sites200, "--concurrency", "5", "--timeout", "5"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            universal_newlines=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        data = json.load(open(out, encoding="utf-8"))
        self.assertEqual(data["total"], 3)
        self.assertEqual(data["ok"], 1)
        por_site = {d["site"]: d for d in data["detalhes"]}
        srv = por_site[f"127.0.0.1:{TRIAGE_PORT}"]
        self.assertTrue(srv["ok"])
        self.assertEqual(srv["status"], 200)
        self.assertEqual(srv["motivo"], "ok")
        self.assertEqual(por_site["127.0.0.1:1"]["motivo"], "conexao")
        self.assertEqual(por_site["hostnaoexiste-xyz.invalid"]["motivo"], "dns")
        self.assertEqual(open(sites200, encoding="utf-8").read().strip(),
                         f"127.0.0.1:{TRIAGE_PORT}")


if __name__ == "__main__":
    unittest.main(verbosity=2)