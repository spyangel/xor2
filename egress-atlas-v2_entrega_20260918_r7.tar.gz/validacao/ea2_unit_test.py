# -*- coding: utf-8 -*-
"""Testes unitários offline das melhorias do egress-atlas v2."""
import io
import os
import sys


def _safe_stdio():
    """Garante stdout/stderr ASCII-safe em Python 3.6 (locale C/ASCII)."""
    for _s in (sys.stdout, sys.stderr):
        if _s is None:
            continue
        _rc = getattr(_s, "reconfigure", None)
        if _rc is not None:  # Python 3.7+
            try:
                _rc(errors="backslashreplace")
            except Exception:
                pass
            continue
        try:
            _enc = _s.encoding or "utf-8"
            if "utf" in _enc.lower() or "65001" in _enc:
                continue
            _buf = getattr(_s, "buffer", None)
            if _buf is None:
                continue
            _new = io.TextIOWrapper(_buf, encoding=_enc,
                                    errors="backslashreplace",
                                    line_buffering=True)
        except Exception:
            continue
        if _s is sys.stdout:
            sys.stdout = _new
        elif _s is sys.stderr:
            sys.stderr = _new


_safe_stdio()

_HERE = os.path.dirname(os.path.abspath(__file__))
for _cand in ("/home/user/egress-atlas-v2",
              os.path.join(_HERE, "..", "egress-atlas-v2")):
    if os.path.isdir(_cand):
        sys.path.insert(0, _cand)
        break

from egress_atlas_v2 import detections, contextual, abuse

PASS = 0
FAIL = 0

def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK] {name}")
    else:
        FAIL += 1
        print(f"  [FALHOU] {name} {extra}")

print("== classify_installer (melhoria: detecção VPN/instalador) ==")
r = detections.classify_installer("wireguard-installer.exe", "https://download.wireguard.com/windows-client/wireguard-installer.exe")
check("wireguard -> is_installer", r["is_installer"] is True, r)
check("wireguard -> risk 3", r["risk"] == 3, r)
check("wireguard -> kind WireGuard", "WireGuard" in r["kind"], r)

r = detections.classify_installer("7z2409-x64.exe", "https://www.7-zip.org/a/7z2409-x64.exe")
check("7-zip -> is_installer", r["is_installer"] is True, r)
check("7-zip -> risk 1", r["risk"] == 1, r)

r = detections.classify_installer("setup_anydesk.exe")
check("anydesk -> risk 2", r["is_installer"] and r["risk"] == 2, r)

r = detections.classify_installer("openvpn-connect-3.4.7.exe")
check("openvpn -> risk 3", r["is_installer"] and r["risk"] == 3, r)

r = detections.classify_installer("tool.exe")
check("exe genérico -> is_installer via extensão", r["is_installer"] is True, r)
check("exe genérico -> risk 2", r["risk"] == 2, r)

r = detections.classify_installer("manual.pdf")
check("pdf genérico -> não instalador", r["is_installer"] is False, r)

r = detections.classify_installer("data.ps1")
check("ps1 -> is_installer", r["is_installer"] is True, r)

print("== detect_downloads (melhoria: achar links .exe/.msi/.zip) ==")
html = '''<html><body>
<a href="/downloads/vpnclient.exe">VPN</a>
<a href="https://cdn.example.com/app-2.0.msi">MSI</a>
<input type="button" onclick="location='/get/archive.zip'">
<a href="/docs/readme.pdf">pdf</a>
<a href="/install/rustdesk-1.2.3.exe"
<a href="/install/winrar-x64.exe">
<script>window.open('/tools/da.bat')</script>
<a onclick="location.href='/upd/patch.ps1'">PS</a>
</body></html>'''
urls = contextual.detect_downloads(html, "https://site.example/portal/")
check("detecta .exe", any(u.endswith(".exe") for u in urls), urls)
check("detecta .msi", any(u.endswith(".msi") for u in urls), urls)
check("detecta onclick zip", any(u.endswith(".zip") for u in urls), urls)
check("onclick location zip", any(u.endswith(".zip") for u in urls), urls)
check("window.open bat", any(u.endswith(".bat") for u in urls), urls)
check("location.href ps1", any(u.endswith(".ps1") for u in urls), urls)
check("leitura truncada de href (sem fechamento)", len(urls) >= 3, urls)
check("não pega .pdf", not any(u.endswith(".pdf") for u in urls), urls)

print("== classify_context (melhoria: contexto decide os testes) ==")
def mk(**kw):
    p = contextual.ContextProbe(url="https://x.example/", host="x.example")
    for k, v in kw.items():
        setattr(p, k, v)
    return p

# estático com downloads -> DOWNLOAD (não STATIC) -> roda installer_download
p = mk(has_download=True, download_urls=["https://x/a.exe"])
contextual.classify_context(p)
check("static+download -> DOWNLOAD", p.category == "DOWNLOAD", p.category)

# CDN com download -> CDN_STATIC (testa installer) e confidence 0.8
p = mk(technologies=["Cloudflare"], has_download=True,
       download_urls=["https://x/a.msi"])
contextual.classify_context(p)
check("cdn+download -> CDN_STATIC", p.category == "CDN_STATIC", p.category)

# formulário ASP.NET -> PORTAL
p = mk(has_form=True, technologies=[".NET"])
contextual.classify_context(p)
check("form+.NET -> PORTAL", p.category == "PORTAL", p.category)

# API json
p = mk(has_api=True)
contextual.classify_context(p)
check("api -> API_REST", p.category == "API_REST", p.category)

# fallback estático
p = mk()
contextual.classify_context(p)
check("sem indícios -> STATIC", p.category == "STATIC", p.category)

print("== CONTEXT_TESTS (melhoria: installer_download onde havia gap) ==")
for ctx in ("SPA", "FORMULARY", "REDIRECT", "STATIC"):
    check(f"{ctx} tem installer_download",
          "installer_download" in abuse.CONTEXT_TESTS[ctx], abuse.CONTEXT_TESTS[ctx])
for ctx, tests in abuse.CONTEXT_TESTS.items():
    for t in tests:
        check(f"dispatcher cobre {ctx}/{t}", t in (
            "echo_query", "post_dead_drop", "post_json_dead_drop",
            "upload_dead_drop", "redirect_control", "websocket_channel",
            "header_exfil", "cors_open", "installer_download"), t)

print("== constantes / typo (correção VERDICT_IMPROVABLE) ==")
check("VERDICT_IMPROBABLE definida", hasattr(abuse, "VERDICT_IMPROBABLE"))
check("VERDICT_IMPROVABLE não existe", not hasattr(abuse, "VERDICT_IMPROVABLE"))
import inspect
src_redirect = inspect.getsource(abuse._probe_redirect)
check("_probe_redirect sem typo", "VERDICT_IMPROVABLE" not in src_redirect.replace("VERDICT_IMPROBABLE", ""), "typo ainda presente!")

print("== beacon por método (melhoria: método do canal confirmado) ==")
src_beacon = inspect.getsource(abuse._probe_beacon)
check("beacon suporta POST", "method == \"POST\"" in src_beacon or "method == 'POST'" in src_beacon)
check("evidência diz 'requests'", "requests respondidos" in src_beacon,
      "texto antigo 'GETs' presente?")

print(f"\nRESULTADO: {PASS} ok, {FAIL} falhas")
sys.exit(1 if FAIL else 0)