# Egresso v2 e2b.local

- **Data:** 2026-09-18 14:24:20
- **Analista:** Dan
- **Host:** e2b.local (Linux 6.1.158+)
- **Proxy:** (direto)

## 1. Análise contextual (triagem)

- Sites analisados: **2**
- Distribuição:
  - API_REST: 1
  - CDN_STATIC: 1
- Tecnologias mais comuns: Cloudflare (1)
- Sites com downloads: 0 | sites com formulários: 0

## 2. Vereditos conclusivos

- **CONFIRMADOS:** 3
- **PROVÁVEIS (confirmar manualmente):** 0

### 2.1 Achados CONFIRMADOS (evidência objetiva)

| Site | Contexto | Teste | Risco | Evidência |
|---|---|---|---|---|
| http://httpbin.org/anything | API_REST | post_dead_drop | 3/3 | POST 200: token ecoado no corpo (dead drop com confirmação) |
| http://httpbin.org/anything | API_REST | echo_query | 3/3 | HTTP 200: token refletido na resposta (exfiltração com confirmação de recebimento) |
| http://httpbin.org/anything | API_REST | cors_open | 1/3 | ACAO: https://evil.example (credenciais: true) — leitura cross-origin possível |

## 4. Estabilidade de beacon (canais confirmados)

| Site | Veredito | Evidência |
|---|---|---|
| http://httpbin.org/anything | CONFIRMADO | 2/2 requests respondidos em 1.2s (p50 135ms) — beacon periódico estável |

## 5. Recomendações de ação (blue team)

1. **Bloquear downloads de clientes VPN/túnel** (seção 3) na política do proxy — maior alavanca contra tunelamento.
2. **Correlacionar egresso por método+corpo:** sites com dead drop confirmado merecem regra de bloqueio de POST ou alerta de volume.
3. **Monitorar reflexão:** sites com echo confirmado permitem exfiltração com confirmação — alertar em consultas com parâmetros longos/base64.
4. **Beaconing:** sites com beacon estável merecem alerta de frequência regular (mesmo host, mesmo caminho, horário fixo).
5. **Revisar CORS aberto** em sites corporativos — permite leitura cross-origin por página maliciosa.

---
*Gerado por egress-atlas v2.1.1*