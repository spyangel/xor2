#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Valida que todos os modulos do egress-atlas v2 usam apenas sintaxe Python 3.6.

Funciona de qualquer um destes lugares:
    python3 validacao/check_py36.py                 # raiz do pacote (irmaos: egress-atlas-v2/ e validacao/)
    python3 ../validacao/check_py36.py              # de dentro de egress-atlas-v2/
    python3 validacao/check_py36.py /caminho/do/egress-atlas-v2   # raiz explicita

Saida esperada: 9/9 arquivos OK. Qualquer FAIL indica sintaxe 3.7+ (walrus,
f-string "=", future import, etc.) que precisa de ajuste.

Nota: em Python < 3.8 o kwarg feature_version nao existe e e ignorado —
o parser nativo da versao em execucao ja aplica a gramatica correta.
As mensagens de saida sao ASCII para nao crashar em locale C/ASCII no 3.6.
"""
import ast
import sys
import pathlib

FILES = [
    "egress_atlas_v2/__init__.py",
    "egress_atlas_v2/cli.py",
    "egress_atlas_v2/contextual.py",
    "egress_atlas_v2/abuse.py",
    "egress_atlas_v2/utils.py",
    "egress_atlas_v2/detections.py",
    "egress_atlas_v2/proxy.py",
    "egress_atlas_v2/report.py",
    "agents/prepare_targets.py",
]

def _safe_stdio() -> None:
    """Garante stdout/stderr ASCII-safe em Python 3.6 (locale C/ASCII)."""
    for stream in (sys.stdout, sys.stderr):
        if stream is None:
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:  # Python 3.7+
            try:
                reconfigure(errors="backslashreplace")
            except Exception:
                pass
            continue
        # Python <= 3.6: preserva a codificacao nativa, erro vira escape ASCII
        try:
            enc = stream.encoding or "utf-8"
            if "utf" in enc.lower() or "65001" in enc:
                continue
            buf = getattr(stream, "buffer", None)
            if buf is None:
                continue
            import io
            new = io.TextIOWrapper(buf, encoding=enc,
                                   errors="backslashreplace",
                                   line_buffering=True)
        except Exception:
            continue
        if stream is sys.stdout:
            sys.stdout = new
        elif stream is sys.stderr:
            sys.stderr = new

def _find_root(given):
    """Resolve o diretorio raiz do projeto (onde ficam egress_atlas_v2/ e agents/)."""
    if given:
        p = pathlib.Path(given)
        return p if (p / FILES[0]).exists() else p / "egress-atlas-v2"
    here = pathlib.Path(".")
    if (here / FILES[0]).exists():
        return here
    cand = here / "egress-atlas-v2"
    return cand if (cand / FILES[0]).exists() else here

def main() -> int:
    _safe_stdio()
    root = _find_root(sys.argv[1] if len(sys.argv) > 1 else None)
    if not (root / FILES[0]).exists():
        print(f"ERRO: nao achei {FILES[0]} sob {root.resolve()}")
        print("Rode a partir da raiz do pacote ou passe o caminho como argumento.")
        return 2
    print(f"Raiz: {root.resolve()}")
    fails = []
    for rel in FILES:
        p = root / rel
        src = p.read_text(encoding="utf-8")
        try:
            ast.parse(src, filename=str(p), feature_version=(3, 6))
        except TypeError:
            # Python < 3.8 nao tem o kwarg feature_version (ele e 3.8+); nesse
            # caso o parser nativo ja valida com a gramatica da propria versao
            # (ex.: rodando no 3.6, qualquer sintaxe 3.7+ falha aqui mesmo).
            ast.parse(src, filename=str(p))
        except SyntaxError as exc:
            fails.append((rel, exc))
            print(f"FAIL 3.6  {rel}: {exc}")
            continue
        print(f"OK  3.6  {rel}")
    if fails:
        print(f"\n{len(fails)} arquivo(s) incompativel(is) com Python 3.6")
        return 1
    print("\nTodos os arquivos sao compativeis com a gramatica Python 3.6")
    return 0

if __name__ == "__main__":
    sys.exit(main())