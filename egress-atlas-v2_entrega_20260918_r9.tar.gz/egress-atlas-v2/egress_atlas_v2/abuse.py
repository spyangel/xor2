# -*- coding: utf-8 -*-
"""Testes direcionados por contexto, com vereditos conclusivos.

Princípio: NADA de bateria genérica. Para cada categoria de contexto, roda
apenas os testes com chance real de provar abuso, e cada veredito exige
evidência objetiva:

  CONFIRMADO    — token recuperado / URL de upload retornada e acessível /
                  handshake 101 / redirect com token no Location /
                  instalador de VPN baixável (HEAD/GET parcial real)
  PROVÁVEL      — comportamento consistente (POST 2xx, upload aceito) mas
                  sem prova de retorno — exige confirmação manual pontual
  IMPROVÁVEL    — teste falhou ou sem evidência

Volume por site: 2 a 6 requests. Nada de dados reais: tokens de 12 bytes.
"""

import os
import re
import time
import urllib.parse
from dataclasses import dataclass, field, asdict
from typing import List, Optional

from . import utils, detections
from .proxy import s as get_session

# installer_download: quantas URLs de download detectadas testar por site.
# 0 (padrao) = TODAS as detectadas (sem corte top-N). Override: EGRESS_INSTALLER_MAX
INSTALLER_DOWNLOAD_MAX = 0
try:
    INSTALLER_DOWNLOAD_MAX = int(os.environ.get("EGRESS_INSTALLER_MAX", "0") or 0)
except ValueError:
    INSTALLER_DOWNLOAD_MAX = 0


VERDICT_CONFIRMED = "CONFIRMADO"
VERDICT_PROBABLE = "PROVAVEL"
VERDICT_IMPROBABLE = "IMPROVAVEL"


@dataclass
class AbuseFinding:
    site: str = ""
    context: str = ""
    test: str = ""                    # ex.: echo_query, dead_drop, upload,
                                      #      installer_vpn, websocket, redirect
    verdict: str = VERDICT_IMPROBABLE
    evidence: str = ""                # evidência objetiva (token/URL/status)
    risk: int = 0                     # 0-3
    detail: dict = field(default_factory=dict)
    duration_ms: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Primitivas de prova
# ---------------------------------------------------------------------------

def _probe_echo_query(site: str, token: str, timeout: float = 8.0) -> AbuseFinding:
    """Token na query string → refletido no corpo/Location/headers?"""
    f = AbuseFinding(site=site, test="echo_query")
    sess = get_session()
    t0 = time.time()
    try:
        sep = "&" if "?" in site else "?"
        r = sess.get(site + sep + "ea=" + token, timeout=timeout)
        reflected = (
            token in r.text[:60000]
            or any(token in (h.headers.get("Location", "") or "") for h in r.history)
            or token in str(r.headers)
        )
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        if reflected:
            f.verdict = VERDICT_CONFIRMED
            f.risk = 3
            f.evidence = (f"HTTP {r.status_code}: token refletido na resposta "
                          f"(exfiltração com confirmação de recebimento)")
            f.detail = {"status": r.status_code, "bytes_body": len(r.content)}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"HTTP {r.status_code}: sem reflexão do token"
            f.detail = {"status": r.status_code}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_post_dead_drop(site: str, token: str, timeout: float = 8.0,
                          as_json: bool = False) -> AbuseFinding:
    """POST de token em form/JSON. Eco na resposta = CONFIRMADO."""
    f = AbuseFinding(site=site, test="post_dead_drop",
                     context="form" if not as_json else "api")
    sess = get_session()
    t0 = time.time()
    try:
        if as_json:
            r = sess.post(site, json={"ea": token}, timeout=timeout)
        else:
            r = sess.post(site, data={"ea": token}, timeout=timeout)
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        if r.status_code < 400:
            if token in r.text[:60000]:
                f.verdict = VERDICT_CONFIRMED
                f.risk = 3
                f.evidence = (f"POST {r.status_code}: token ecoado no corpo "
                              f"(dead drop com confirmação)")
            else:
                f.verdict = VERDICT_PROBABLE
                f.risk = 2
                f.evidence = (f"POST {r.status_code} sem eco: aceita payload — "
                              f"dead drop unidirecional provável; confirmar "
                              f"manualmente se o conteúdo persiste")
            f.detail = {"status": r.status_code}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"POST {r.status_code}: não aceita payload"
            f.detail = {"status": r.status_code}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_upload(site: str, token: str, timeout: float = 8.0) -> AbuseFinding:
    """Upload multipart de PNG sintético (token no chunk tEXt).

    Se a resposta trouxer URL do arquivo, tenta GET para recuperar o token
    → dead drop binário completo = CONFIRMADO.
    """
    f = AbuseFinding(site=site, test="upload_dead_drop")
    sess = get_session()
    t0 = time.time()
    try:
        # PNG sintético com o token embutido em metadado tEXt
        png = utils.b64url_decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJ"
                                  "AAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
        fname = f"ea_{token[:8]}.png"
        r = sess.post(site, files={"file": (fname, png, "image/png")},
                      timeout=timeout)
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        body = r.text[:60000]
        # procura URL de arquivo retornada
        m = re.search(r'(https?://[^\s"\'<>]+(?:ea_[0-9a-f]{8}\.png|upload[^\s"\'<>]*))',
                      body, re.I)
        if r.status_code < 400 and m:
            url = m.group(1)
            # tenta recuperar o arquivo
            r2 = sess.get(url, timeout=timeout)
            if r2.status_code < 400 and token[:8] in r2.text[:100000]:
                f.verdict = VERDICT_CONFIRMED
                f.risk = 3
                f.evidence = (f"upload {r.status_code} → URL {url} → arquivo "
                              f"recuperável com o token (dead drop binário completo)")
                f.detail = {"upload_url": url, "fetch_status": r2.status_code}
            else:
                f.verdict = VERDICT_CONFIRMED  # upload aceito + URL retornada
                f.risk = 2
                f.evidence = (f"upload {r.status_code} → URL {url} retornada "
                              f"(conteúdo não verificado)")
                f.detail = {"upload_url": url}
        elif r.status_code < 400:
            f.verdict = VERDICT_PROBABLE
            f.risk = 2
            f.evidence = (f"upload aceito (HTTP {r.status_code}) sem URL "
                          f"retornada — provável dead drop binário; confirmar "
                          f"manualmente")
            f.detail = {"status": r.status_code}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"upload rejeitado (HTTP {r.status_code})"
            f.detail = {"status": r.status_code}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_redirect(site: str, token: str, timeout: float = 8.0) -> AbuseFinding:
    """Redirect controlável? Token em parâmetro → Location com token."""
    f = AbuseFinding(site=site, test="redirect_control")
    sess = get_session()
    t0 = time.time()
    try:
        # tenta padrões comuns de open redirect
        candidates = [
            site + ("&" if "?" in site else "?") + "url=" + token,
            site + ("&" if "?" in site else "?") + "next=" + token,
            site + ("&" if "?" in site else "?") + "redirect=" + token,
            site + ("&" if "?" in site else "?") + "redirect_url=" + token,
        ]
        for c in candidates:
            r = sess.get(c, timeout=timeout, allow_redirects=False)
            loc = r.headers.get("Location", "")
            if r.status_code in (301, 302, 303, 307, 308):
                f.duration_ms = round((time.time() - t0) * 1000, 1)
                if token in loc:
                    f.verdict = VERDICT_CONFIRMED
                    f.risk = 2
                    f.evidence = (f"HTTP {r.status_code} com token no Location "
                                  f"({loc[:100]}) — redirect utilizável para "
                                  f"hijack de fluxo/exfil")
                    f.detail = {"location": loc[:200]}
                    return f
                f.detail = {"location": loc[:200], "token_reflected": False}
        f.verdict = VERDICT_IMPROBABLE
        f.evidence = "sem redirect controlável com token"
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_websocket(site: str, timeout: float = 6.0) -> AbuseFinding:
    """Handshake WebSocket 101 = canal bidirecional real = CONFIRMADO."""
    f = AbuseFinding(site=site, test="websocket_channel")
    sess = get_session()
    t0 = time.time()
    try:
        ws_url = site.replace("http://", "ws://").replace("https://", "wss://")
        r = sess.get(ws_url, timeout=timeout,
                     headers={"Connection": "Upgrade", "Upgrade": "websocket",
                              "Sec-WebSocket-Version": "13",
                              "Sec-WebSocket-Key": "ZXZpbC1lZ3Jlc3MtbWFya2Vy"},  # inócuo
                     allow_redirects=False)
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        if r.status_code == 101:
            f.verdict = VERDICT_CONFIRMED
            f.risk = 3
            f.evidence = "handshake WebSocket 101 — túnel bidirecional real"
            f.detail = {"status": 101}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"handshake recusado (HTTP {r.status_code})"
            f.detail = {"status": r.status_code}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_installer(site: str, dl_url: str, timeout: float = 10.0) -> AbuseFinding:
    """Valida que o download funciona VIA PROXY e classifica o instalador.

    Usa GET com Range (bytes=0-4095) para não baixar o arquivo inteiro.
    """
    f = AbuseFinding(site=site, test="installer_download")
    sess = get_session()
    t0 = time.time()
    try:
        fn = urllib.parse.unquote(urllib.parse.urlparse(dl_url).path.split("/")[-1])
        cls = detections.classify_installer(fn, dl_url)
        r = sess.get(dl_url, timeout=timeout,
                     headers={"Range": "bytes=0-4095"})
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        ctype = r.headers.get("Content-Type", "")
        clen = r.headers.get("Content-Length", r.headers.get("Content-Range", "?"))
        if r.status_code in (200, 206) and cls["is_installer"]:
            f.verdict = VERDICT_CONFIRMED
            f.risk = cls["risk"]
            f.evidence = (f"baixável via proxy (HTTP {r.status_code}, "
                          f"{clen} bytes, {ctype or '?'}) — {cls['kind']} "
                          f"(risco {cls['risk']}/3)")
            f.detail = {"filename": fn, "kind": cls["kind"], "risk": cls["risk"],
                        "content_type": ctype, "size": clen}
        elif r.status_code in (200, 206):
            f.verdict = VERDICT_PROBABLE
            f.risk = 1
            f.evidence = (f"baixável via proxy (HTTP {r.status_code}) — arquivo "
                          f"{fn} sem assinatura de VPN/acesso remoto; revisar "
                          f"manualmente")
            f.detail = {"filename": fn, "content_type": ctype, "size": clen}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"download falhou (HTTP {r.status_code})"
            f.detail = {"status": r.status_code}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_header_exfil(site: str, token: str, timeout: float = 8.0) -> AbuseFinding:
    """Header custom X-EA-* → refletido na resposta (header ou corpo)."""
    f = AbuseFinding(site=site, test="header_exfil")
    sess = get_session()
    t0 = time.time()
    try:
        r = sess.get(site, timeout=timeout,
                     headers={"X-EA-Test": token, "X-Egress-Probe": token})
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        if token in r.text[:60000] or token in str(r.headers):
            f.verdict = VERDICT_CONFIRMED
            f.risk = 2
            f.evidence = "header custom refletido — exfil em header possível"
            f.detail = {"status": r.status_code}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"sem reflexão (HTTP {r.status_code})"
            f.detail = {"status": r.status_code}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_cors(site: str, timeout: float = 8.0) -> AbuseFinding:
    """CORS aberto → leitura cross-origin de dados do site por página maliciosa."""
    f = AbuseFinding(site=site, test="cors_open")
    sess = get_session()
    t0 = time.time()
    try:
        r = sess.get(site, timeout=timeout, headers={"Origin": "https://evil.example"})
        f.duration_ms = round((time.time() - t0) * 1000, 1)
        acao = r.headers.get("Access-Control-Allow-Origin", "")
        acac = r.headers.get("Access-Control-Allow-Credentials", "")
        if acao == "*" or acao == "https://evil.example":
            f.verdict = VERDICT_CONFIRMED
            f.risk = 1
            f.evidence = (f"ACAO: {acao} (credenciais: {acac or 'não'}) — "
                          f"leitura cross-origin possível")
            f.detail = {"acao": acao, "acac": acac}
        else:
            f.verdict = VERDICT_IMPROBABLE
            f.evidence = f"ACAO: {acao or '(ausente)'}"
            f.detail = {"acao": acao}
    except Exception as e:
        f.evidence = f"{type(e).__name__}: {e!r}"
    return f


def _probe_beacon(site: str, cycles: int = 3, interval: float = 3.0,
                  timeout: float = 8.0, method: str = "GET") -> AbuseFinding:
    """Beacon curto — mede se o canal confirmado responde de forma estável.

    Usa o MESMO método do canal confirmado (GET para echo, POST para dead
    drop) — beacon de C2 real usa o canal que funciona, não um GET genérico.
    """
    f = AbuseFinding(site=site, test="beacon_stability")
    sess = get_session()
    t0 = time.time()
    acks = 0
    lats = []
    for i in range(cycles):
        t1 = time.time()
        try:
            if method == "POST":
                r = sess.post(site, data={"beacon": i, "t": "ea-beacon"},
                              timeout=timeout)
            else:
                r = sess.get(site, timeout=timeout)
            if r.status_code < 400:
                acks += 1
                lats.append((time.time() - t1) * 1000)
        except Exception:
            pass
        if i < cycles - 1:
            time.sleep(interval)
    f.duration_ms = round((time.time() - t0) * 1000, 1)
    if acks >= max(2, cycles - 1):
        f.verdict = VERDICT_CONFIRMED
        f.risk = 2
        p50 = sorted(lats)[len(lats) // 2] if lats else 0
        f.evidence = (f"{acks}/{cycles} requests respondidos em "
                      f"{round(f.duration_ms/1000, 1)}s (p50 {round(p50)}ms) — "
                      f"beacon periódico estável")
        f.detail = {"acked": acks, "cycles": cycles, "p50_ms": round(p50)}
    else:
        f.verdict = VERDICT_IMPROBABLE
        f.evidence = f"{acks}/{cycles} requests respondidos — beacon instável"
        f.detail = {"acked": acks, "cycles": cycles}
    return f


# ---------------------------------------------------------------------------
# Mapeamento contexto → testes
# ---------------------------------------------------------------------------

CONTEXT_TESTS = {
    "API_REST":   ["post_json_dead_drop", "cors_open", "echo_query",
                   "redirect_control"],
    "SPA":        ["echo_query", "header_exfil", "cors_open",
                   "redirect_control", "installer_download"],
    "CMS":        ["upload_dead_drop", "post_dead_drop", "echo_query",
                   "installer_download"],
    "ECOMMERCE":  ["post_dead_drop", "echo_query", "installer_download"],
    "PORTAL":     ["post_dead_drop", "echo_query", "installer_download"],
    "CDN_STATIC": ["echo_query", "header_exfil", "installer_download",
                   "redirect_control"],
    "WEBSOCKET":  ["websocket_channel"],
    "UPLOAD":     ["upload_dead_drop", "post_dead_drop"],
    "DOWNLOAD":   ["installer_download", "echo_query"],
    "FORMULARY":  ["post_dead_drop", "echo_query", "installer_download"],
    "REDIRECT":   ["redirect_control", "echo_query", "installer_download"],
    "STATIC":     ["echo_query", "header_exfil", "redirect_control",
                    "installer_download"],
    "BLOCKED":    [],
}


def run_context_tests(probe, timeout: float = 8.0) -> List[AbuseFinding]:
    """Roda os testes adequados ao contexto do site. Retorna findings."""
    site = probe.url
    context = probe.category
    tests = CONTEXT_TESTS.get(context, [])
    findings = []
    token = utils.random_token(12)

    for test in tests:
        if test == "echo_query":
            findings.append(_probe_echo_query(site, token, timeout))
        elif test == "post_dead_drop":
            findings.append(_probe_post_dead_drop(site, token, timeout,
                                                  as_json=False))
        elif test == "post_json_dead_drop":
            findings.append(_probe_post_dead_drop(site, token, timeout,
                                                  as_json=True))
        elif test == "upload_dead_drop":
            findings.append(_probe_upload(site, token, timeout))
        elif test == "redirect_control":
            findings.append(_probe_redirect(site, token, timeout))
        elif test == "websocket_channel":
            findings.append(_probe_websocket(site, timeout))
        elif test == "header_exfil":
            findings.append(_probe_header_exfil(site, token, timeout))
        elif test == "cors_open":
            findings.append(_probe_cors(site, timeout))
        elif test == "installer_download":
            # 0 = testa TODAS as URLs de download detectadas (sem corte top-3)
            dls = probe.download_urls
            if INSTALLER_DOWNLOAD_MAX > 0:
                dls = dls[:INSTALLER_DOWNLOAD_MAX]
            for dl in dls:
                findings.append(_probe_installer(site, dl, timeout))
    return findings


def summarize_findings(findings: List[AbuseFinding]) -> dict:
    confirmed = [f for f in findings if f.verdict == VERDICT_CONFIRMED]
    probable = [f for f in findings if f.verdict == VERDICT_PROBABLE]
    by_test = {}
    for f in findings:
        by_test.setdefault(f.test, {"confirmed": 0, "probable": 0, "total": 0})
        by_test[f.test]["total"] += 1
        if f.verdict == VERDICT_CONFIRMED:
            by_test[f.test]["confirmed"] += 1
        elif f.verdict == VERDICT_PROBABLE:
            by_test[f.test]["probable"] += 1
    return {
        "total_findings": len(findings),
        "confirmed": len(confirmed),
        "probable": len(probable),
        "by_test": by_test,
    }
