"""egress-atlas v2 — avaliação contextualizada e conclusiva de egresso via webproxy.

v2 muda a abordagem:
1. Análise contextual PRÉVIA (1 request/site, 100 threads) classifica o site
   por tipo, tecnologias e recursos (upload, download, formulário, API, WS...).
2. Testes DIRECIONADOS por contexto — nada de bateria genérica em todo site.
3. Vereditos CONCLUSIVOS: cada hipótese de abuso vira CONFIRMADO/IMPROVÁVEL
   com evidência objetiva (token recuperado, URL retornada, redirect com eco...).
4. Foco em valor real para ameaça interna em desktop Windows gerenciado:
   instaladores (clientes VPN), dead drops, reflexão, túnel, beaconing.
"""

__version__ = "2.1.4"