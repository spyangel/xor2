#!/usr/bin/env bash
# ============================================================================
# egress-atlas v2.1.4 — orquestrador Linux (Bad Samurai online/offline)
#
# Pipeline:
#   ONLINE : fetch (listas do Bad Samurai) → process (normaliza/filtra)
#   OFFLINE: process direto sobre as listas locais
#            → triage (conectividade + HTTP 2xx) → analyze → test → beacon
#            → report (só nos sites que responderam HTTP 200)
#
# Uso:
#   ./agents/scan_v2.sh online  [OUT]               # baixa as listas do Bad Samurai
#   ./agents/scan_v2.sh offline [ARQUIVO...] [OUT]  # uma ou mais listas locais
#   ./agents/scan_v2.sh help
#
#   offline sem ARQUIVO usa todos os *.txt do diretório corrente (menos os
#   artefatos do próprio pipeline). O OUT relativo é criado no diretório
#   onde o comando foi executado; ARQUIVO relativo também (não no do script).
#
# Env:
#   CONC=60              threads da análise contextual
#   TRIAGE_CONC=100      threads da triagem (conectividade + HTTP 200)
#   TRIAGE_TIMEOUT=12    timeout por request na triagem (s)
#   TRIAGE_MAX=          limita o nº de sites triados (vazio/0 = todos)
#   CONTEXT_MAX=0        máx. sites por contexto nos testes (0 = TODOS)
#   TOTAL_MAX=0          máx. total de sites testados (0 = TODOS os HTTP 200)
#   INSTALLER_MAX=0      máx. downloads testados por site (0 = TODOS)
#   BEACON_CYCLES=3 / BEACON_INTERVAL=3
#
#   Por default NÃO há corte top-N: todos os sites HTTP 200 são testados.
#   Defina CONTEXT_MAX/TOTAL_MAX>0 (ou use config.yaml) para reduzir volume.
#   BS_LISTS=            sobrescreve as listas do Bad Samurai (nomes ou URLs)
#   PYTHON=/caminho/python3.6   força um interpretador específico (override)
# ============================================================================
set -euo pipefail

INVOKE_DIR="$(pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PREP="$SCRIPT_DIR/prepare_targets.py"

# Garante que o pacote egress_atlas_v2 resolva independente do cwd (o script
# pode ser invocado de fora do diretório do projeto: ./egress-atlas-v2/agents/scan_v2.sh)
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

CONC="${CONC:-60}"
TRIAGE_CONC="${TRIAGE_CONC:-100}"
TRIAGE_TIMEOUT="${TRIAGE_TIMEOUT:-12}"
TRIAGE_MAX="${TRIAGE_MAX:-}"
CONTEXT_MAX="${CONTEXT_MAX:-0}"    # 0 = sem limite por contexto
TOTAL_MAX="${TOTAL_MAX:-0}"        # 0 = sem teto global (todos os HTTP 200)
BEACON_CYCLES="${BEACON_CYCLES:-3}"
BEACON_INTERVAL="${BEACON_INTERVAL:-3}"

if [ -n "${PYTHON:-}" ]; then
    PY="$PYTHON"                      # override explícito (ex.: seu Python 3.6)
elif [ -x "$ROOT/.venv/bin/python" ]; then
    PY="$ROOT/.venv/bin/python"
else
    PY=python3
fi

log() { echo -e "\033[1;34m[*] $(date +%H:%M:%S) $*\033[0m"; }
die() { echo -e "\033[1;31m[-] $*\033[0m" >&2; exit 1; }

abs_path() { case "$1" in /*) echo "$1" ;; *) echo "$INVOKE_DIR/$1" ;; esac; }

uso() {
    sed -n '3,33p' "$0" | sed 's/^# \{0,1\}//' | grep -v '^$'
}

command -v python3 >/dev/null || die "python3 ausente"
$PY -c "import requests" 2>/dev/null || die \
  "deps ausentes → python3 -m venv .venv && .venv/bin/pip install requests pyyaml"
"$PY" -c "import egress_atlas_v2" 2>/dev/null || die \
  "pacote egress_atlas_v2 nao encontrado — extraia o pacote inteiro (pastas " \
  "agents/ e egress_atlas_v2/ lado a lado) e rode o script pelo caminho: " \
  "$ROOT/agents/scan_v2.sh"

MODO="${1:-}"
shift || true

case "$MODO" in
  help|--help|-h)
    uso; exit 0 ;;
  online)
    OUT="$(abs_path "${1:-results_v2_online}")"
    mkdir -p "$OUT"
    log "MODO ONLINE — Bad Samurai (bs-lists), saída em $OUT"
    log "Fase 0a — download das listas do Bad Samurai"
    "$PY" "$PREP" fetch --out "$OUT/bs_cru.txt"
    log "Fase 0b — normalização e filtro de não-websites"
    "$PY" "$PREP" process --in "$OUT/bs_cru.txt" \
        --out "$OUT/lista_limpa.txt" --stats "$OUT/preparacao.json" ;;
  offline)
    LISTAS=()
    OUT=""
    for a in "$@"; do
        if [ -f "$a" ] || [ -f "$(abs_path "$a")" ]; then
            LISTAS+=("$(abs_path "$a")")          # arquivo existente = lista
        elif [[ "$a" == *.txt ]]; then
            log "  [!] '$a' inexistente ignorado (possivel typo de lista)"
        else
            OUT="$a"                               # diretorio ou novo = saida
        fi
    done
    if [ "${#LISTAS[@]}" -eq 0 ]; then
        log "offline sem argumentos — usando *.txt do diretório corrente"
        for f in "$INVOKE_DIR"/*.txt; do
            [ -e "$f" ] || continue
            case "$(basename "$f")" in
                sites_200*|bs_cru*|lista_limpa*|preparacao*|triagem*) continue ;;
            esac
            LISTAS+=("$f")
        done
    fi
    if [ "${#LISTAS[@]}" -eq 0 ]; then
        die "nenhuma lista .txt encontrada no diretório corrente " \
            "($INVOKE_DIR) — passe o caminho como argumento"
    fi
    OUT="$(abs_path "${OUT:-results_v2_offline}")"
    mkdir -p "$OUT"
    log "MODO OFFLINE — ${#LISTAS[@]} lista(s) local(is), saída em $OUT"
    for l in "${LISTAS[@]}"; do log "  fonte: $l"; done
    IN_ARGS=()
    for l in "${LISTAS[@]}"; do IN_ARGS+=(--in "$l"); done
    log "Fase 0 — normalização e filtro de não-websites"
    "$PY" "$PREP" process "${IN_ARGS[@]}" \
        --out "$OUT/lista_limpa.txt" --stats "$OUT/preparacao.json" ;;
  *)
    die "modo inválido ou ausente: '$MODO'\n\n$(uso)" ;;
esac

log "Triagem — conectividade (DNS) e HTTP 2xx " \
    "(${TRIAGE_CONC} threads, timeout ${TRIAGE_TIMEOUT}s)"
TRIAGE_ARGS=(--list "$OUT/lista_limpa.txt" --out "$OUT/triagem.json" \
             --sites200 "$OUT/sites_200.txt" \
             --concurrency "$TRIAGE_CONC" --timeout "$TRIAGE_TIMEOUT")
[ -n "$TRIAGE_MAX" ] && TRIAGE_ARGS+=(--max "$TRIAGE_MAX")
"$PY" "$PREP" triage "${TRIAGE_ARGS[@]}" || \
    die "nenhum site com HTTP 200 — nada a testar (veja $OUT/triagem.json)"

N_200="$(wc -l < "$OUT/sites_200.txt")"
log "$N_200 site(s) HTTP 200 — seguem os testes contextuais"

export EGRESS_TEST_MAX_CONTEXT="$CONTEXT_MAX"
export EGRESS_TEST_MAX_TOTAL="$TOTAL_MAX"
export EGRESS_INSTALLER_MAX="${INSTALLER_MAX:-0}"

log "Fase 1 — análise contextual (${CONC} threads)"
$PY -m egress_atlas_v2.cli analyze --list "$OUT/sites_200.txt" \
    --concurrency "$CONC" -o "$OUT/context.json"

if [ "$TOTAL_MAX" -gt 0 ] 2>/dev/null; then
    log "Fase 2 — testes direcionados por contexto (máx ${TOTAL_MAX} sites)"
else
    log "Fase 2 — testes direcionados por contexto (sem limite: todos os sites HTTP 200)"
fi
$PY -m egress_atlas_v2.cli test -f "$OUT/context.json" -o "$OUT/findings.json"

log "Fase 3 — beaconing curto em canais confirmados"
$PY -m egress_atlas_v2.cli beacon -f "$OUT/findings.json" \
    --cycles "$BEACON_CYCLES" --interval "$BEACON_INTERVAL" \
    -o "$OUT/beacon.json"

log "Fase 4 — relatório"
$PY -m egress_atlas_v2.cli report -o "$OUT" -n "Egresso v2 $(hostname)"

log "Concluído. Resultados em $OUT/"
ls -la "$OUT" | grep -E "bs_cru|lista_limpa|triagem|sites_200|context|findings|beacon|egress_v2"