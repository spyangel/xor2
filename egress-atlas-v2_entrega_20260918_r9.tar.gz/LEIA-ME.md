# egress-atlas v2.1.4 — pacote completo (r9)

Ferramenta de **avaliação contextual de websites abusáveis via webproxy corporativo**
(perspectiva insider em desktop Windows: Defender, GPO, proxy), alimentada pelas listas
do **Bad Samurai** (`BadSamuraiDev/bs-lists`).

Compatível com **Python 3.6+** (ambiente do usuário confirmado: **Python 3.6.8**;
release validada de ponta a ponta em Python **3.6.15 real** com locale ASCII).

> **Novo em 2.1.4 — sem corte top-N.** Por padrão são testados **TODOS** os sites
> que responderam **HTTP 200** (nenhum limite por categoria, nenhum teto global,
> nenhum corte no beaconing e nenhum corte nos downloads por site). Os limites
> continuam existindo, mas desligados por default (`0` = ilimitado) e configuráveis
> via `config.yaml` ou variáveis de ambiente.

## Estrutura (pacote completo — este é o projeto inteiro, não um diff)

```
egress-atlas-v2/                 ← CÓDIGO-FONTE COMPLETO
├── agents/
│   ├── scan_v2.sh               ← ORQUESTRADOR (modos online/offline; sem corte top-N por default)
│   └── prepare_targets.py       ← fetch (Bad Samurai) + process (filtro) + triage (HTTP 2xx)
├── egress_atlas_v2/             ← pacote Python (8 módulos; __init__.py = v2.1.4)
│   ├── cli.py                   ← CLI analyze / test / beacon / report (seleção SEM limite top-N)
│   ├── contextual.py            ← classificação de contexto (API, CDN, portal…)
│   ├── abuse.py                 ← classes de abuso + testes direcionados por contexto
│   ├── detections.py            ← detecções em página (downloads, forms, hints…)
│   ├── proxy.py                 ← checagens de proxy corporativo (NTLM sob demanda)
│   ├── utils.py                 ← utilitários (threads, tolerâncias, harden_stdio)
│   └── report.py                ← relatórios JSON/MD/CSV
├── config.yaml                  ← proxy corporativo, limites por contexto (0 = sem limite)
└── requirements.txt             ← 100% ASCII, pinagens compatíveis com Python 3.6
validacao/                       ← VALIDAÇÃO (suítes, checador 3.6, evidências E2E)
├── check_py36.py                ← valida a gramática 3.6 dos 9 arquivos (saída ASCII)
├── ea2_unit_test.py             ← suíte do projeto (71 testes; APIs 3.6-safe)
├── test_prepare_targets.py      ← suíte do preparador (24 testes; APIs 3.6-safe)
├── e2e_py36/                    ← E2E offline em Python 3.6.15 REAL (25 sites HTTP 200 → prova sem corte top-N)
├── e2e_offline/                 ← evidências do E2E offline (pipeline inteiro, v2.1.1)
└── e2e_online/                  ← evidências do E2E online (15 listas Bad Samurai)
LEIA-ME.md
```

## Requisitos

- **Python 3.6 ou superior** (confirmado no ambiente 3.6.8 do usuário; validado em
  3.6.15 e 3.13).
- `pip install -r requirements.txt` instala: `requests>=2.26.0` (2.28+ exige 3.7),
  `pyyaml>=6.0` e o backport `dataclasses` no 3.6 (stdlib só no 3.7+).
- Opcionais: `requests-ntlm2` (proxy NTLM, importado sob demanda; **validado no 3.6.15**),
  `websocket-client`/`cryptography` (Python ≥3.7; **não** são importados pelos módulos).

## Instalação

```bash
cd egress-atlas-v2
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

Nenhuma configuração de locale é necessária: o `requirements.txt` é 100% ASCII e os
CLIs protegem stdout/stderr (`harden_stdio`) — instalação e `--help` funcionam mesmo
com o sistema em locale C/ASCII.

Valide a compatibilidade 3.6 na sua máquina:

```bash
python3 --version                        # 3.6.8 esperado
.venv/bin/python ../validacao/check_py36.py   # 9/9 OK = sintaxe compatível 3.6
```

## Uso

```bash
# O script é chamável de QUALQUER diretório (não precisa cd para a pasta):
# o caminho do pacote é resolvido pelo próprio script (PYTHONPATH + preflight).

# OFFLINE — uma ou mais listas locais (ou todos os *.txt do diretório corrente)
./agents/scan_v2.sh offline [lista1.txt lista2.txt ...] [OUT]

# ONLINE — baixa as 15 listas do Bad Samurai (BadSamuraiDev/bs-lists) e roda o pipeline
./agents/scan_v2.sh online [OUT]

./agents/scan_v2.sh help     # lembrete dos modos e variáveis
```

Pipeline (sempre o mesmo após a preparação dos alvos):
**normaliza/filtra → triagem (DNS + HTTP 2xx) → analyze → test → beacon → report**
— os testes contextuais rodam somente nos sites que responderam **HTTP 200** e, por
padrão, em **todos** eles (sem corte top-N).

## Sem corte top-N (v2.1.4) — o que muda

| Onde | 2.1.3 (antes) | 2.1.4 (agora) |
|---|---|---|
| Sites por contexto (`max_sites_per_context`) | 15 | **0 = todos** |
| Teto global de sites (`max_total_sites`) | 80 | **0 = todos** |
| Beacon (`max_sites`, só canais CONFIRMADOS) | 10 | **0 = todos** |
| Downloads por site (`installer_download`) | top 3 | **0 = todos os detectados** |

Convenção: **`0` (ou negativo) = ilimitado**, igual ao `--max 0 = todos` do
`prepare_targets.py`. A ordenação por prioridade de contexto continua existindo, mas
agora define apenas a **ordem de execução** — nenhum site é descartado.

Para voltar a reduzir o volume (ex.: smoke test), basta definir valores > 0:

```bash
# só os 15 primeiros por categoria e no máximo 80 no total
CONTEXT_MAX=15 TOTAL_MAX=80 ./agents/scan_v2.sh online saida
```

ou editar `config.yaml` (`test.max_sites_per_context` / `test.max_total_sites` /
`beacon.max_sites`).

## Filtro do que NÃO é website (motivos em `validacao/e2e_py36/preparacao.json` / `preparacao.json` da sua execução)

- `email` — endereço e-mail / userinfo em URL
- `extensao` — arquivo (exe, msi, zip, pdf, docx, pem, key, aws, cfg…)
- `invalido` — entrada sem TLD, underscore, porta fora de faixa, espaço…
- `nao_http` — schema ftp://, file:// etc.
- `duplicado` — repetido entre listas

> `.com` NUNCA é tratado como extensão (é TLD). Novos gTLDs abusados como `.zip`
> são tratados como extensão — decisão deliberada.

## Variáveis de ambiente

| Var | Default | Uso |
|---|---|---|
| `TRIAGE_CONC` | 100 | threads da triagem |
| `TRIAGE_TIMEOUT` | 12 | timeout por request na triagem (s) |
| `TRIAGE_MAX` | (todos) | limita nº de sites triados (smoke/testes) |
| `CONC` | 60 | threads da análise contextual |
| `CONTEXT_MAX` | **0 (todos)** | máx. sites por contexto nos testes |
| `TOTAL_MAX` | **0 (todos)** | máx. total de sites testados |
| `INSTALLER_MAX` | **0 (todos)** | máx. downloads testados por site |
| `BEACON_CYCLES` / `BEACON_INTERVAL` | 3 / 3 | beaconing (0 = todos os canais confirmados) |
| `BS_LISTS` | (15 oficiais) | sobrescreve as listas do Bad Samurai |

Ex.: `TRIAGE_MAX=100 ./agents/scan_v2.sh online saida_teste`

## Validação incluída (2026-09-22 — r9)

- **E2E offline completo em Python 3.6.15 real (locale C/ASCII), cwd arbitrário
  (`/tmp`)**: pipeline process→triage→analyze→test→beacon→report VERDE com
  **25 sites HTTP 200 locais** — prova objetiva de que **não há corte top-N**:
  - filtro: 28 entradas → 26 mantidas (`extensao`: 1, `email`: 1)
  - triagem: **25/26 HTTP 200** (1 site `/status404` rejeitado)
  - seleção: **"testes direcionados em 25 sites"** + log `limites top-N desativados`
  - resultados: **25 CONFIRMADOS** (echo_query) em 25 sites distintos
  - beacon: **25/25 sites confirmados** (antes o teto era 10)
  - evidências em `validacao/e2e_py36/` (`LOG_execucao.txt`, JSONs, lista e servidor local)
- **Regressão do limite (override ainda funciona)**: `EGRESS_TEST_MAX_TOTAL=15`
  reduz a seleção para 15 sites; sem a variável, 25 — comportamento correto em ambos.
- Sintaxe Python 3.6 (ast feature_version 3.6): **9/9 arquivos** (`check_py36.py`)
- Suíte do projeto (`ea2_unit_test.py`): **71 ok / 0 falhas** (3.6.15 e 3.13)
- Suíte do preparador (`test_prepare_targets.py`): **24 ok / 0 falhas** (3.6.15 e 3.13)
- `pip install -r requirements.txt` sob locale ASCII no 3.6.15: OK
- `--help` dos CLIs em locale C: OK (sem UnicodeEncodeError)
- E2E offline (v2.1.1): `validacao/e2e_offline/` · E2E online (15 listas):
  `validacao/e2e_online/`
- `bash -n agents/scan_v2.sh`: OK · md5 das fontes: idênticas ao projeto
- `scan_v2.sh help` e `python -m egress_atlas_v2.cli --help` de cwd arbitrário
  (Python 3.6.15, LC_ALL=C): exit 0 — bug #4 (ModuleNotFoundError) corrigido via
  `export PYTHONPATH="$ROOT"` + preflight de import com mensagem orientativa

## Histórico de versões

- **2.1.4 (atual)** — **fim do corte top-N**: `test.max_sites_per_context`,
  `test.max_total_sites` e `beacon.max_sites` passam a **0 = todos** por default
  (antes 15 / 80 / 10) e o probe `installer_download` deixa de limitar a 3 URLs
  por site. Tratamento centralizado de limite em `cli._as_limit()` (0/negativo/
  inválido = ilimitado) e ordenação por contexto mantida apenas como ordem de
  execução. `scan_v2.sh` com `CONTEXT_MAX=0`, `TOTAL_MAX=0`, novo
  `INSTALLER_MAX=0` e mensagem de fase dinâmica. Validado com E2E de 25 sites
  HTTP 200 em Python 3.6.15 (sem corte) + regressão do override (`TOTAL_MAX=15`).
  UA do `prepare_targets.py` sincronizada (2.1.4).
- **2.1.3** — fix do `ModuleNotFoundError: No module named 'egress_atlas_v2'`
  ao invocar `./egress-atlas-v2/agents/scan_v2.sh` de fora do diretório do
  projeto: `scan_v2.sh` exporta `PYTHONPATH="$ROOT"` e faz preflight
  `python -c "import egress_atlas_v2"` com mensagem orientativa se o pacote
  não for encontrado. Validado com o cenário exato do erro (cwd arbitrário,
  Python 3.6.15 real, LC_ALL=C, pipeline E2E completo verde). UA do
  `prepare_targets.py` sincronizada (2.1.3).
- **2.1.2** — compat Python 3.6+ (2ª rodada de hardening, validado em 3.6.15
  real): `argparse` sem `required=True` nos subparsers (`prepare_targets.py`),
  `harden_stdio()` nos CLIs (fim do `UnicodeEncodeError` em locale ASCII),
  `requirements.txt` reescrito 100% ASCII (fim do erro de pip em locale ASCII),
  harnesses de teste convertidos para APIs 3.6 (`ThreadingHTTPServer` shim,
  `universal_newlines`, handler sem kwarg `directory`, `encoding="utf-8"` nos
  `open()`), `check_py36.py` com saída ASCII.
- **2.1.1** — compat Python 3.6+: remoção dos 8 `from __future__ import annotations`
  (recurso 3.7+), `list[...]` → `typing.List` nas assinaturas, `text=True` →
  `universal_newlines=True` em proxy.py, requirements.txt repineado.
- **2.1.0** — pipeline Bad Samurai online/offline (`prepare_targets.py` fetch/process/triage;
  `scan_v2.sh` modos `online`/`offline`).
- **2.0.2** — correção de path relativo em `scan_v2.sh` (INVOKE_DIR + SCRIPT_DIR).
