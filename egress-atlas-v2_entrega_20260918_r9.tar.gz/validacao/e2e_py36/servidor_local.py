# -*- coding: utf-8 -*-
"""Servidor HTTP local (Python 3.6-safe) para o E2E r9.

Serve 25 "sites" (/s1..s25) que respondem HTTP 200 e refletem o parametro
`ea` no corpo -> gera echo_query CONFIRMADO e prova:
  - SEM corte top-N: os 25 sites HTTP 200 entram na analise e nos testes
  - beacon sem teto: beacon roda em todos os confirmados (>= 20)
Inclui /status404 (para provar rejeicao de nao-200).
"""
import sys
import threading

try:
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from socketserver import ThreadingMixIn
except ImportError:  # pragma: no cover
    raise SystemExit("sem http.server")

NSITES = 25


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):        # silencioso
        pass

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        query = self.path.split("?", 1)[1] if "?" in self.path else ""
        if path == "/status404":
            self.send_response(404)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body>not found</body></html>")
            return
        if path.startswith("/s") and path[2:].isdigit():
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            body = "<html><body>site %s ok" % path
            if "ea=" in query:
                tok = ""
                for kv in query.split("&"):
                    if kv.startswith("ea="):
                        tok = kv[3:]
                body += " echo:%s" % tok
            body += "</body></html>"
            self.wfile.write(body.encode("utf-8"))
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"<html><body>root</body></html>")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length:
            self.rfile.read(length)
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(b"<html><body>posted</body></html>")


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9001
    srv = _Server(("127.0.0.1", port), _Handler)
    sys.stderr.write("[srv] ouvindo em 127.0.0.1:%d (%d sites)\n" % (port, NSITES))
    sys.stderr.flush()
    srv.serve_forever()


if __name__ == "__main__":
    main()
