#!/usr/bin/env bash
# ============================================================================
# egress-atlas v2 — orquestrador Linux
# Pipeline contextual: analyze → test → beacon → report
#
# Uso:
#   ./agents/scan_v2.sh sites.txt results_v2
# Env:
#   CONC=100        threads da análise contextual
#   CONTEXT_MAX=15  máx. sites por contexto nos testes
#   TOTAL_MAX=80    máx. total de sites testados
#   BEACON_CYCLES=3 / BEACON_INTERVAL=3
# ============================================================================
set -euo pipefail

LIST="${1:-sites.txt}"
OUT="${2:-results_v2}"
CONC="${CONC:-100}"
CONTEXT_MAX="${CONTEXT_MAX:-15}"
TOTAL_MAX="${TOTAL_MAX:-80}"
BEACON_CYCLES="${BEACON_CYCLES:-3}"
BEACON_INTERVAL="${BEACON_INTERVAL:-3}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p "$OUT"

if [ -x "$ROOT/.venv/bin/python" ]; then
    PY="$ROOT/.venv/bin/python"
else
    PY=python3
fi

log() { echo -e "\033[1;34m[*] $(date +%H:%M:%S) $*\033[0m"; }
die() { echo -e "\033[1;31m[-] $*\033[0m" >&2; exit 1; }

command -v python3 >/dev/null || die "python3 ausente"
$PY -c "import requests" 2>/dev/null || die \
  "deps ausentes → python3 -m venv .venv && .venv/bin/pip install requests pyyaml"
[ -f "$LIST" ] || die "lista não encontrada: $LIST"

log "Proxy: ${https_proxy:-${HTTPS_PROXY:-${http_proxy:-SEM-PROXY-EXPLICITO}}}"

# limites de teste via env (lidos pelo CLI)
export EGRESS_TEST_MAX_CONTEXT="$CONTEXT_MAX"
export EGRESS_TEST_MAX_TOTAL="$TOTAL_MAX"

log "Fase 1 — análise contextual ($(wc -l < "$LIST") sites, ${CONC} threads)"
$PY -m egress_atlas_v2.cli analyze --list "$LIST" \
    --concurrency "$CONC" -o "$OUT/context.json"

log "Fase 2 — testes direcionados por contexto (máx ${TOTAL_MAX} sites)"
$PY -m egress_atlas_v2.cli test -f "$OUT/context.json" -o "$OUT/findings.json"

log "Fase 3 — beaconing curto em canais confirmados"
$PY -m egress_atlas_v2.cli beacon -f "$OUT/findings.json" \
    --cycles "$BEACON_CYCLES" --interval "$BEACON_INTERVAL" \
    -o "$OUT/beacon.json"

log "Fase 4 — relatório"
$PY -m egress_atlas_v2.cli report -o "$OUT" -n "Egresso v2 $(hostname)"

log "Concluído. Resultados em $OUT/"
ls -la "$OUT" | grep -E "context|findings|beacon|egress_v2"