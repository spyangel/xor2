# -*- coding: utf-8 -*-
"""Análise contextual prévia: categoriza sites por tipo e tecnologia.

Objetivo: escolher os testes adequados para cada contexto, reduzindo
falsos positivos e tempo de execução.

Categorias:
  API_REST      — endpoints JSON, CORS, rate limiting
  SPA           — Single Page App (React, Angular, Vue)
  CMS           — WordPress, Drupal, Joomla
  ECOMMERCE     — Shopify, Magento, WooCommerce
  PORTAL        — Intranet, portal corporativo, login
  CDN_STATIC    — Cloudflare, Akamai, AWS CloudFront
  WEBSOCKET     — WebSockets, SSE, long polling
  UPLOAD        — aceita uploads de arquivos
  DOWNLOAD      — arquivos para download (EXE, ZIP, MSI)
  FORMULARY     — formulários HTML com POST
  REDIRECT      — open redirect, 301/302
  STATIC        — página estática simples
  BLOCKED       — inacessível/proxy bloqueou
"""
from __future__ import annotations

import concurrent.futures as cf
import re
import time
import urllib.parse
from dataclasses import dataclass, field, asdict
from typing import Optional

import requests

from .proxy import s as get_session


@dataclass
class ContextProbe:
    url: str = ""
    host: str = ""
    category: str = "STATIC"
    category_confidence: float = 0.0
    technologies: list = field(default_factory=list)
    framework: str = ""
    server: str = ""
    has_upload: bool = False
    has_download: bool = False
    has_form: bool = False
    has_api: bool = False
    has_websocket: bool = False
    has_redirect: bool = False
    is_spa: bool = False
    is_cdn: bool = False
    is_cms: bool = False
    is_ecommerce: bool = False
    is_portal: bool = False
    download_urls: list = field(default_factory=list)
    form_urls: list = field(default_factory=list)
    api_endpoints: list = field(default_factory=list)
    response_time_ms: float = 0.0
    status: int = 0
    content_type: str = ""
    content_length: int = 0
    notes: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Detecção de tecnologias
# ---------------------------------------------------------------------------

TECH_PATTERNS = {
    "React": [r"react\.js", r"react-dom", r"rel=\"canonical\"", r"webpack"],
    "Angular": [r"angular\.js", r"ng-", r"angular"],
    "Vue": [r"vue\.js", r"vue-router"],
    ".NET": [r"\.NET Framework", r"ASP\.NET", r"Microsoft-IIS", r"X-AspNet"],
    "PHP": [r"PHP/", r"phpinfo", r"X-Powered-By: PHP"],
    "Node.js": [r"nodejs", r"express", r"koa"],
    "Java": [r"Jakarta", r"Servlet", r"JSP"],
    "WordPress": [r"wp-content", r"wp-includes", r"WordPress"],
    "Drupal": [r"Drupal", r"drupal\.js"],
    "Joomla": [r"Joomla", r"media/jui"],
    "Shopify": [r"shopify", r"cdn\.shopify"],
    "Magento": [r"magento", r"var/output"],
    "Cloudflare": [r"cloudflare", r"__cfduid"],
    "Akamai": [r"akamai", r"__akami"],
    "AWS": [r"amazonaws", r"cloudfront"],
}

FORM_PATTERNS = [
    r'<form[^>]*action="([^"]*)"',
    r'<input[^>]*type="submit"',
    r'<button[^>]*type="submit"',
]

DOWNLOAD_PATTERNS = [
    # atributos href/src com extensão executável/empacotada
    r'\b(?:href|src)\s*=\s*["\']([^"\']*\.(?:exe|msi|zip|rar|7z|dmg|pkg)["\'])',
    r'\b(?:href|src)\s*=\s*["\']([^"\']*\.(?:dll|so|deb|rpm)["\'])',
    # extensões de script/empacotamento do FILE_EXT_RISK (alinhado ao detections)
    r'\b(?:href|src)\s*=\s*["\']([^"\']*\.(?:bat|ps1|cmd|jar|iso)["\'])',
    # window.open('/x.exe') — chamada direta
    r'\bwindow\.open\s*\(\s*["\']([^"\']*\.(?:exe|msi|zip|rar|7z|bat|ps1|cmd|iso)["\'])',
    # location[.href] = '/x.exe' — atribuição JS (inclusive dentro de onclick)
    r'\b(?:location|document\.location|window\.location)(?:\.href)?\s*=\s*["\']([^"\']*\.(?:exe|msi|zip|rar|7z|bat|ps1|cmd|iso)["\'])',
    # action de submit apontando para binário (gateways de download)
    r'\baction\s*=\s*["\']([^"\']*\.(?:exe|msi|zip|bat|ps1)["\'])',
]

API_PATTERNS = [
    r'/api/v?\d*/',
    r'/api/auth',
    r'/api/users',
    r'/api/data',
    r'/rest/',
    r'/graphql',
]

WEBSOCKET_PATTERNS = [
    r'new WebSocket',
    r'ws://',
    r'wss://',
    r'WebSocket\.CONNECTING',
]


def detect_technologies(body: str, headers: dict) -> list[str]:
    """Detecta tecnologias no corpo e headers da resposta."""
    techs = []
    body_lower = body.lower()
    header_str = str(headers).lower()
    
    for tech, patterns in TECH_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, body_lower, re.I) or re.search(pattern, header_str, re.I):
                if tech not in techs:
                    techs.append(tech)
                break
    return techs


def detect_forms(body: str) -> list[str]:
    """Detecta URLs de formulários no corpo."""
    forms = []
    for pattern in FORM_PATTERNS:
        matches = re.findall(pattern, body, re.I)
        forms.extend(matches)
    return list(set(forms))[:10]  # limita a 10


def detect_downloads(body: str, url: str) -> list[str]:
    """Detecta URLs de download (EXE, ZIP, MSI, etc.)."""
    downloads = []
    base_url = urllib.parse.urljoin(url, "/")
    
    for pattern in DOWNLOAD_PATTERNS:
        matches = re.findall(pattern, body, re.I)
        for match in matches:
            if isinstance(match, tuple):
                url_match = match[1]
            else:
                url_match = match
            full_url = urllib.parse.urljoin(base_url, url_match.strip('"\''))
            if full_url not in downloads:
                downloads.append(full_url)
    
    return downloads[:20]  # limita a 20


def detect_api_endpoints(body: str, url: str, headers: dict = None) -> list[str]:
    """Detecta endpoints de API no corpo e headers."""
    apis = []
    base_url = urllib.parse.urljoin(url, "/")
    
    for pattern in API_PATTERNS:
        matches = re.findall(pattern, body, re.I)
        apis.extend(matches)
    
    # também verifica headers CORS
    if headers:
        cors = headers.get("Access-Control-Allow-Origin", "")
        if cors:
            apis.append("CORS enabled")
    
    return list(set(apis))[:15]


def detect_websockets(body: str) -> bool:
    """Detecta uso de WebSockets no corpo."""
    for pattern in WEBSOCKET_PATTERNS:
        if re.search(pattern, body, re.I):
            return True
    return False


# ---------------------------------------------------------------------------
# Classificação contextual
# ---------------------------------------------------------------------------

def classify_context(probe: ContextProbe) -> None:
    """Classifica o site baseado na análise feita."""
    techs = probe.technologies
    body = probe.notes  # placeholder para corpo
    
    # CDN/Static
    if any(t in techs for t in ["Cloudflare", "Akamai", "AWS"]):
        probe.is_cdn = True
        if not probe.has_api and not probe.has_form:
            probe.category = "CDN_STATIC"
            probe.category_confidence = 0.8
    
    # CMS
    elif any(t in techs for t in ["WordPress", "Drupal", "Joomla"]):
        probe.is_cms = True
        probe.category = "CMS"
        probe.category_confidence = 0.9
    
    # E-commerce
    elif any(t in techs for t in ["Shopify", "Magento"]):
        probe.is_ecommerce = True
        probe.category = "ECOMMERCE"
        probe.category_confidence = 0.85
    
    # SPA
    elif any(t in techs for t in ["React", "Angular", "Vue"]):
        probe.is_spa = True
        probe.category = "SPA"
        probe.category_confidence = 0.75
    
    # Portal
    elif probe.has_form and any(t in techs for t in [".NET", "PHP", "Java"]):
        probe.is_portal = True
        probe.category = "PORTAL"
        probe.category_confidence = 0.7
    
    # API REST
    elif probe.has_api:
        probe.category = "API_REST"
        probe.category_confidence = 0.8
    
    # WebSocket
    elif probe.has_websocket:
        probe.category = "WEBSOCKET"
        probe.category_confidence = 0.85
    
    # Upload
    elif probe.has_upload:
        probe.category = "UPLOAD"
        probe.category_confidence = 0.75
    
    # Download
    elif probe.has_download:
        probe.category = "DOWNLOAD"
        probe.category_confidence = 0.7
    
    # Form
    elif probe.has_form:
        probe.category = "FORMULARY"
        probe.category_confidence = 0.65
    
    # Redirect
    elif probe.has_redirect:
        probe.category = "REDIRECT"
        probe.category_confidence = 0.6
    
    # Static (default)
    else:
        probe.category = "STATIC"
        probe.category_confidence = 0.5


def _probe_context_one(raw_url: str, timeout: float = 8.0) -> ContextProbe:
    """Analisa um site e retorna o contexto detectado."""
    url = raw_url.strip()
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    
    probe = ContextProbe(url=url, host=urllib.parse.urlparse(url).hostname)
    sess = get_session()
    t0 = time.time()
    
    try:
        # stream=True: nao baixa binarios inteiros (ex.: instaladores).
        # Ler apenas os primeiros ~100KB e fechar a conexao evita que a
        # fase analyze consuma banda/tempo baixando arquivos grandes.
        r = sess.get(url, timeout=timeout, allow_redirects=True, stream=True)
        probe.response_time_ms = round((time.time() - t0) * 1000, 1)
        probe.status = r.status_code
        probe.content_type = (r.headers.get("Content-Type") or "").split(";")[0]
        probe.server = r.headers.get("Server", "")

        cl_hdr = r.headers.get("Content-Length")
        chunks = []
        total = 0
        try:
            for chunk in r.iter_content(65536):
                chunks.append(chunk)
                total += len(chunk)
                if total >= 100_000:
                    break
        finally:
            r.close()
        # content_length: header real quando presente, senao bytes lidos
        probe.content_length = int(cl_hdr) if cl_hdr and cl_hdr.isdigit() else total
        body = b"".join(chunks).decode("utf-8", errors="replace")
        
        # detecta tecnologias
        probe.technologies = detect_technologies(body, r.headers)
        probe.framework = probe.technologies[0] if probe.technologies else ""
        
        # detecta recursos
        probe.has_form = bool(detect_forms(body))
        probe.has_download = bool(detect_downloads(body, url))
        probe.has_api = bool(detect_api_endpoints(body, url, r.headers))
        probe.has_websocket = detect_websockets(body)
        # redirect real = histórico de redirecionamentos (o status final
        # nunca é 3xx com allow_redirects=True)
        probe.has_redirect = bool(r.history)
        # API por content-type: respostas JSON são o maior vetor de dead drop
        if not probe.has_api and probe.content_type in (
                "application/json", "application/hal+json",
                "application/vnd.api+json", "text/json"):
            probe.has_api = True
            probe.notes.append("content-type json → API surface")
        
        # URLs específicas
        probe.form_urls = detect_forms(body)
        probe.download_urls = detect_downloads(body, url)
        probe.api_endpoints = detect_api_endpoints(body, url, r.headers)
        
        # classifica
        classify_context(probe)
        
    except requests.exceptions.Timeout:
        probe.status = -1
        probe.category = "BLOCKED"
        probe.notes.append("timeout")
    except requests.exceptions.ConnectionError:
        probe.status = -2
        probe.category = "BLOCKED"
        probe.notes.append("connection error")
    except requests.exceptions.RetryError:
        # 5xx após retries de conexão — site acessível, resposta degradada
        probe.status = 500
        probe.notes.append("retry exaurido (5xx)")
        probe.category = "STATIC"
    except Exception as e:
        probe.status = -3
        probe.category = "BLOCKED"
        probe.notes.append(f"error: {type(e).__name__}")
    
    return probe


def run_contextual_analysis(urls: list[str], concurrency: int = 50,
                            timeout: float = 8.0, progress=None) -> list[ContextProbe]:
    """Analisa o contexto de todos os sites em paralelo."""
    results: list[ContextProbe] = []
    total = len(urls)
    
    with cf.ThreadPoolExecutor(max_workers=concurrency) as ex:
        futs = {ex.submit(_probe_context_one, u, timeout): u for u in urls}
        done = 0
        
        for fut in cf.as_completed(futs):
            probe = fut.result()
            results.append(probe)
            done += 1
            
            if progress and done % 100 == 0:
                progress(f"contextual {done}/{total}")
    
    # ordena por categoria (mais promissores primeiro)
    priority = {
        "API_REST": 1, "UPLOAD": 2, "DOWNLOAD": 3, "WEBSOCKET": 4,
        "SPA": 5, "CMS": 6, "ECOMMERCE": 7, "PORTAL": 8,
        "FORMULARY": 9, "REDIRECT": 10, "CDN_STATIC": 11,
        "STATIC": 12, "BLOCKED": 99,
    }
    results.sort(key=lambda x: priority.get(x.category, 99))
    
    return results


def summarize_context(results: list[ContextProbe]) -> dict:
    """Resumo da análise contextual."""
    cats = {}
    techs = {}
    downloads = []
    forms = []
    
    for p in results:
        cats[p.category] = cats.get(p.category, 0) + 1
        
        for tech in p.technologies:
            techs[tech] = techs.get(tech, 0) + 1
        
        if p.download_urls:
            downloads.append({"url": p.url, "downloads": p.download_urls})
        if p.form_urls:
            forms.append({"url": p.url, "forms": p.form_urls})
    
    return {
        "total": len(results),
        "by_category": cats,
        "by_technology": techs,
        "sites_with_downloads": len(downloads),
        "sites_with_forms": len(forms),
        "top_downloads": downloads[:20],
        "top_forms": forms[:20],
    }
