#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prepare_targets v2.1 — preparação da lista alvo do egress-atlas.

Subcomandos:
  fetch   — modo ONLINE: baixa as listas de URLs do repositório oficial
            BadSamuraiDev/bs-lists (GitHub raw) e concatena num arquivo cru.
  process — normaliza, filtra o que NÃO é website (e-mail, extensão de
            arquivo, schema não-HTTP, entrada inválida) e deduplica.
  triage  — conectividade (DNS) + acessibilidade HTTP; considera acessível
            todo site cujo status final (após redirects) seja 2xx, e grava
            a lista de sites que passaram (sites_200.txt).

Uso:
  prepare_targets.py fetch  --out CRU.txt
  prepare_targets.py process --in A.txt [--in B.txt ...] --out LIMPO.txt [--stats S.json]
  prepare_targets.py triage --list LIMPO.txt --out TRIAGEM.json --sites200 SITES_200.txt

Env:
  BS_LISTS    — sobrescreve as listas do Bad Samurai (nomes ou URLs, separados
                por espaço). Listas de extensões são sempre ignoradas.
"""

import argparse
import io
import json
import os
import re
import socket
import sys
import time
import warnings
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

__version__ = "2.1.3"
UA = "egress-atlas-v2/2.1.3 (assessment; contact: security team)"

BS_RAW_URL = "https://raw.githubusercontent.com/BadSamuraiDev/bs-lists/main/{nome}"

# Listas de URLs do Bad Samurai — websites potencialmente abusáveis via proxy
# (exfil, C2, túnel, download, redirect). Estas são as fontes do modo online.
BS_LISTAS_URL = [
    "alt-browsers.txt",
    "chat-hooks.txt",
    "cloud-ide.txt",
    "file-mirrors.txt",
    "geoshitties.txt",
    "json-storage.txt",
    "living-off-trusted-tunnels.txt",
    "login-cloud-service-providers.txt",
    "login-registrar.txt",
    "online-pdf-editors.txt",
    "open-redirect.txt",
    "pastebins-code.txt",
    "pastebins.txt",
    "risky-devtools.txt",
    "webhooks.txt",
]

# Listas de EXTENSÕES do Bad Samurai — nunca são websites; se chegarem via
# BS_LISTS, são ignoradas (o filtro de extensões também as derruba depois).
BS_LISTAS_EXTENSOES = {"email-file-extensions.txt", "sensitive-file-extensions.txt"}

# Extensões de arquivo comuns que NÃO são TLDs legítimos de websites.
# (Alguns novos gTLDs como .zip/.mov existem, mas são usados quase só para
# abuso — para este caso de uso, tratar como extensão é a decisão correta.)
EXT_BLACKLIST = {
    # binários, instaladores, pacotes
    "exe", "msi", "zip", "rar", "7z", "dmg", "pkg", "apk", "deb", "rpm", "jar",
    "iso", "dll", "so", "dylib", "bin", "dat", "img", "cab", "msix", "appx",
    "vhd", "vmdk", "wim", "gz", "tar", "bz2", "xz", "tgz",
    # scripts e automação (risco alto — alinhado ao FILE_EXT_RISK da ferramenta)
    "bat", "ps1", "cmd", "sh", "py", "pyc", "js", "jsx", "ts", "tsx", "vbs",
    # OBS: "com" é intencionalmente EXCLUÍDO — .com é o TLD dominante da
    # internet; tratá-lo como extensão derrubaria a maioria dos sites reais.
    "hta", "wsf", "reg", "inf", "scr", "bash_history",
    # documentos e office
    "doc", "docx", "xls", "xlsx", "xlsm", "ppt", "pptx", "odt", "ods", "odp",
    "rtf", "pdf", "wps", "mdb", "accdb", "html", "htm", "php", "asp", "aspx",
    "jsp",
    # mídia e fontes
    "mp3", "mp4", "wav", "flac", "ogg", "ogv", "avi", "mkv", "mov", "wmv",
    "webm", "m4a", "aac", "swf", "gif", "png", "jpg", "jpeg", "webp", "svg",
    "ico", "avif", "bmp", "tif", "tiff", "eps", "psd", "ai", "ttf", "otf",
    "woff", "woff2", "eot",
    # dados, logs e cache
    "db", "sql", "sqlite", "csv", "txt", "log", "json", "xml", "yaml", "yml",
    "toml", "ini", "cfg", "conf", "config", "cnf", "properties", "env", "pid",
    "lock", "tmp", "bak", "old", "swp", "swo", "dump", "pcap", "pcapng", "cap",
    # credenciais e segredos (vem da sensitive-file-extensions do BS)
    "pem", "key", "crt", "cer", "der", "p7b", "p12", "pfx", "jks", "keystore",
    "truststore", "id_rsa", "aws", "boto", "cscfg", "dockerconfig", "htpasswd",
    "netrc", "pgpass", "s3cfg", "cred", "token", "secret", "private", "pub",
    "asc",
}

# hostname válido: etiquetas seguidas de ponto + TLD alfabético (sem porta)
RE_HOSTNAME = re.compile(
    r"^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$", re.I)
RE_IPV4 = re.compile(r"^(?:\d{1,3})(?:\.\d{1,3}){3}$")


def _log(msg: str) -> None:
    print(msg, flush=True)


def _die(msg: str) -> None:
    print(f"[-] {msg}", file=sys.stderr)
    sys.exit(1)


def _sessao() -> requests.Session:
    warnings.filterwarnings("ignore",
                            category=requests.packages.urllib3.exceptions
                            .InsecureRequestWarning)
    s = requests.Session()
    s.verify = False
    s.headers.setdefault("User-Agent", UA)
    return s


# ---------------------------------------------------------------------------
# process — normalização e filtragem
# ---------------------------------------------------------------------------

def _host_valido(host: str) -> bool:
    """host[:porta] válido como website (hostname com TLD ou IPv4)."""
    if not host or " " in host or "\t" in host:
        return False
    if host.count(":") > 1:          # IPv6 fora de escopo das listas
        return False
    h = host
    if ":" in host:
        h, porta = host.rsplit(":", 1)
        if not porta.isdigit() or not (1 <= int(porta) <= 65535):
            return False
        h = h.rstrip(".")
    if not h:
        return False
    if RE_IPV4.match(h):
        return True
    return bool(RE_HOSTNAME.match(h))


def _tld_de(host: str) -> str:
    h = host.split(":", 1)[0].rstrip(".")
    etiquetas = h.split(".")
    return etiquetas[-1].lower() if len(etiquetas) >= 2 else ""


def _normaliza_token(tok: str):
    """Devolve (entrada_normalizada, None) ou (None, motivo_da_remoção)."""
    if "@" in tok:                                  # e-mail / userinfo
        return None, "email"
    if tok.startswith("//"):                        # protocol-relative
        tok = tok[2:]
    m_url = re.match(r"^([A-Za-z][A-Za-z0-9+.\-]*)://(.*)$", tok)
    if m_url:
        scheme, rest = m_url.group(1).lower(), m_url.group(2)
        if scheme not in ("http", "https"):
            return None, "nao_http"
        if "@" in rest:
            return None, "email"
        tok = rest
    if tok.startswith("||"):                        # formato adblock
        tok = tok[2:]
    if tok.endswith("^"):                           # fim de regra adblock
        tok = tok[:-1]
    tok = tok.lstrip(".*")                          # wildcard: .foo.com / *.foo.com
    if not tok or "//" in tok or " " in tok or "\t" in tok or "://" in tok:
        return None, "invalido"
    host, sep, resto = tok.partition("/")
    if not sep:
        host, sep_q, resto = tok.partition("?")
        resto = ("?" + resto) if sep_q else ""
    else:
        resto = "/" + resto
    host = host.lower().rstrip(".")
    if not host or not _host_valido(host):
        return None, "invalido"
    if _tld_de(host) in EXT_BLACKLIST:
        return None, "extensao"
    entrada = host + resto
    return entrada, None


def cmd_process(args) -> int:
    total = 0
    removidos: Counter = Counter()
    mantidos: list = []
    vistos: set = set()
    for p in args.inp:
        if not os.path.exists(p):
            _die(f"arquivo não encontrado: {p}")
        _log(f"[*] lendo {p}")
        with open(p, encoding="utf-8", errors="ignore") as f:
            for raw in f:
                tok = raw.strip().lstrip("\ufeff")
                if not tok or tok[0] in "#![":
                    continue
                total += 1
                entrada, motivo = _normaliza_token(tok)
                if motivo:
                    removidos[motivo] += 1
                    continue
                if entrada.lower() in vistos:
                    removidos["duplicado"] += 1
                    continue
                vistos.add(entrada.lower())
                mantidos.append(entrada)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(mantidos) + ("\n" if mantidos else ""))
    stats = {
        "fontes": args.inp,
        "entradas_nao_vazias": total,
        "mantidas": len(mantidos),
        "removidas": dict(removidos),
        "saida": args.out,
    }
    if args.stats:
        os.makedirs(os.path.dirname(args.stats) or ".", exist_ok=True)
        with open(args.stats, "w", encoding="utf-8") as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
    _log(f"[+] {len(mantidos)} websites mantidos | "
         f"removidos: {dict(removidos) or 'nenhum'}")
    _log(f"[+] lista limpa salva em {args.out}")
    return 0 if mantidos else 1


# ---------------------------------------------------------------------------
# fetch — modo online (Bad Samurai)
# ---------------------------------------------------------------------------

def _base_sem_ext(nome: str) -> str:
    """'foo.txt'/'foo.md'/'foo.json' -> 'foo' (para comparar listas de extensões)."""
    return re.sub(r"\.(?:txt|md|json)$", "", nome, flags=re.I)


def cmd_fetch(args) -> int:
    env = os.environ.get("BS_LISTS", "").strip()
    fontes = env.split() if env else list(BS_LISTAS_URL)
    ext_base = {_base_sem_ext(x) for x in BS_LISTAS_EXTENSOES}
    fontes = [f for f in fontes if _base_sem_ext(f) not in ext_base]
    if not fontes:
        _die("nenhuma fonte: BS_LISTS vazio ou contendo apenas listas de extensões")
    sess = _sessao()
    blocos: list = []
    ok = 0
    for nome in fontes:
        if "://" in nome or nome.startswith("http"):
            tentativas = [nome]
            rotulo = nome.rsplit("/", 1)[-1]
        else:
            rotulo = nome if nome.endswith((".txt", ".md")) else nome + ".txt"
            tentativas = [BS_RAW_URL.format(nome=rotulo)]
            if rotulo.endswith(".txt"):      # repo BS tem alguns arquivos .md
                tentativas.append(BS_RAW_URL.format(nome=rotulo[:-4] + ".md"))
        ultimo_erro = None
        baixou = False
        for url in tentativas:
            try:
                r = sess.get(url, timeout=30)
                r.raise_for_status()
                linhas = r.text.splitlines()
                blocos.append(
                    f"# ==== fonte: {rotulo} ({len(linhas)} linhas) ====\n{r.text}")
                ok += 1
                baixou = True
                _log(f"[+] {rotulo}: {len(linhas)} linhas")
                break
            except Exception as e:
                ultimo_erro = e
        if not baixou:
            _log(f"[-] falha em {rotulo}: "
                 f"{ultimo_erro.__class__.__name__}: {ultimo_erro}")
    if not blocos:
        _die("nenhuma lista do Bad Samurai pôde ser baixada — verifique "
             "rede/proxy (https_proxy) e tente de novo")
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(blocos) + "\n")
    _log(f"[+] {ok} lista(s) baixada(s) do Bad Samurai → {args.out}")
    return 0


# ---------------------------------------------------------------------------
# triage — conectividade (DNS) + HTTP 2xx
# ---------------------------------------------------------------------------

def _probe_um(site: str, timeout_s: float) -> dict:
    t0 = time.time()
    d = {"site": site, "ok": False, "motivo": "pendente",
         "status": None, "demora_ms": 0}
    host = site.split("/", 1)[0].split(":", 1)[0]
    try:
        socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        d["motivo"] = "dns"
        d["demora_ms"] = int((time.time() - t0) * 1000)
        return d
    sess = _sessao()
    try:
        r = sess.get("http://" + site,
                     timeout=(timeout_s, timeout_s),
                     allow_redirects=True, stream=True)
        d["status"] = r.status_code
        d["ok"] = 200 <= r.status_code < 300
        d["motivo"] = "ok" if d["ok"] else "http"
        r.close()
    except requests.exceptions.SSLError:
        d["motivo"] = "ssl"
    except (requests.exceptions.ConnectTimeout,
            requests.exceptions.ReadTimeout):
        d["motivo"] = "timeout"
    except requests.exceptions.ProxyError:
        d["motivo"] = "proxy"
    except requests.exceptions.ConnectionError:
        d["motivo"] = "conexao"
    except Exception:
        d["motivo"] = "outro"
    d["demora_ms"] = int((time.time() - t0) * 1000)
    return d


def cmd_triage(args) -> int:
    if not os.path.exists(args.list):
        _die(f"lista não encontrada: {args.list}")
    sites = []
    with open(args.list, encoding="utf-8", errors="ignore") as f:
        for raw in f:
            s = raw.strip()
            if s and not s.startswith("#"):
                sites.append(s)
    if args.max and args.max > 0:
        sites = sites[:args.max]
    if not sites:
        _die("lista vazia — nada para triar")
    _log(f"[*] triagem de {len(sites)} site(s) "
         f"({args.concurrency} threads, timeout {args.timeout}s)")
    detalhes: list = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futs = {ex.submit(_probe_um, s, args.timeout): s for s in sites}
        for f in as_completed(futs):
            detalhes.append(f.result())
    detalhes.sort(key=lambda x: (not x["ok"], x["site"]))
    ok_sites = [d["site"] for d in detalhes if d["ok"]]
    resumo = Counter(d["motivo"] for d in detalhes)
    payload = {
        "gerado_em": time.strftime("%Y-%m-%d %H:%M:%S"),
        "criterio": "status final HTTP 2xx (redirects seguidos) "
                    "após resolução DNS",
        "timeout_s": args.timeout,
        "total": len(sites),
        "ok": len(ok_sites),
        "resumo_motivos": dict(resumo),
        "detalhes": detalhes,
        "sites_ok": ok_sites,
    }
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    with open(args.sites200, "w", encoding="utf-8") as f:
        f.write("\n".join(ok_sites) + ("\n" if ok_sites else ""))
    _log(f"[+] HTTP 2xx: {len(ok_sites)}/{len(sites)} | "
         f"motivos: {dict(resumo)}")
    _log(f"[+] triagem salva em {args.out} | sites 200 em {args.sites200}")
    return 0 if ok_sites else 1


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _harden_stdio() -> None:
    """Evita UnicodeEncodeError em stdout/stderr com locale nao-UTF-8 (Py 3.6).

    Mantem a codificacao nativa do stream e troca o modo de erro para
    backslashreplace: acentos imprimem normal em cp1252/UTF-8 e viram
    escapes ASCII em locale C/ASCII, sem derrubar o processo.
    """
    for stream in (sys.stdout, sys.stderr):
        if stream is None:
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:  # Python 3.7+
            try:
                reconfigure(errors="backslashreplace")
            except Exception:
                pass
            continue
        try:
            enc = stream.encoding or "utf-8"
            if "utf" in enc.lower() or "65001" in enc:
                continue
            buf = getattr(stream, "buffer", None)
            if buf is None:
                continue
            new = io.TextIOWrapper(buf, encoding=enc,
                                   errors="backslashreplace",
                                   line_buffering=True)
        except Exception:
            continue
        if stream is sys.stdout:
            sys.stdout = new
        elif stream is sys.stderr:
            sys.stderr = new


def main() -> int:
    _harden_stdio()  # evita UnicodeEncodeError em locale nao-UTF-8 (Py 3.6)
    ap = argparse.ArgumentParser(
        prog="prepare_targets",
        description="Preparação da lista alvo do egress-atlas v2.1 "
                    "(Bad Samurai online ou listas locais).")
    sub = ap.add_subparsers(dest="cmd")  # required=True é 3.7+ (bpo-26510); checagem manual abaixo

    p_fetch = sub.add_parser("fetch", help="baixa listas do Bad Samurai (online)")
    p_fetch.add_argument("--out", required=True, help="arquivo cru de saída")
    p_fetch.set_defaults(func=cmd_fetch)

    p_proc = sub.add_parser("process", help="normaliza, filtra e deduplica")
    p_proc.add_argument("--in", dest="inp", action="append", required=True,
                        help="arquivo de entrada (repetível)")
    p_proc.add_argument("--out", required=True, help="lista limpa de saída")
    p_proc.add_argument("--stats", default="",
                        help="JSON com estatísticas da remoção (opcional)")
    p_proc.set_defaults(func=cmd_process)

    p_tri = sub.add_parser("triage", help="conectividade + HTTP 2xx")
    p_tri.add_argument("--list", required=True, help="lista limpa de entrada")
    p_tri.add_argument("--out", required=True, help="JSON da triagem")
    p_tri.add_argument("--sites200", required=True,
                       help="lista de sites HTTP 2xx (saída)")
    p_tri.add_argument("--concurrency", type=int, default=100,
                       help="threads (default 100)")
    p_tri.add_argument("--timeout", type=float, default=12.0,
                       help="timeout por request em s (default 12)")
    p_tri.add_argument("--max", type=int, default=0,
                       help="limita o nº de sites triados (0 = todos)")
    p_tri.set_defaults(func=cmd_triage)

    args = ap.parse_args()
    if not getattr(args, "cmd", None):
        ap.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())