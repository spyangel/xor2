# egress-atlas v2.1.0 — pacote de entrega (r4)

Avaliação contextual de websites abusáveis via webproxy corporativo (perspectiva insider
em desktop Windows: Defender, GPO, proxy) com listas do **B'ad Samurai**.

## Estrutura

```
egress-atlas-v2/
├── agents/
│   ├── scan_v2.sh            ← ORQUESTRADOR (modos online/offline)
│   └── prepare_targets.py    ← fetch (Bad Samurai) + process (filtro) + triage (HTTP 2xx)
├── egress_atlas_v2/          ← pacote Python (7 módulos; __init__.py = v2.1.0)
├── config.yaml               ← proxy corporativo, limites por contexto
└── requirements.txt
validacao/                    ← relatório de validação, suítes de teste e evidências E2E
LEIA-ME.md
```

## Instalação

```bash
cd egress-atlas-v2
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
# opcionais: websocket-client, cryptography, requests-ntlm2 (proxy NTLM)
```

## Uso

```bash
# OFFLINE — uma ou mais listas locais (ou todos os *.txt do diretório corrente)
./agents/scan_v2.sh offline [lista1.txt lista2.txt ...] [OUT]

# ONLINE — baixa as listas do B'ad Samurai (BadSamuraiDev/bs-lists) e roda o pipeline
./agents/scan_v2.sh online [OUT]

./agents/scan_v2.sh help     # lembrete dos modos e variáveis
```

O pipeline é SEMPRE o mesmo após a preparação dos alvos:
**normaliza/filtra → triagem (DNS + HTTP 2xx) → analyze → test → beacon → report**
— os testes contextuais rodam somente nos sites que responderam **HTTP 200**.

## Filtro do que NÃO é website (motivos em validacao/preparacao.json)

- `email` — endereço e-mail / userinfo em URL
- `extensao` — arquivo (exe, msi, zip, pdf, docx, pem, key, aws, cfg…)
- `invalido` — entrada sem TLD, underscore, porta fora de faixa, espaço…
- `nao_http` — schema ftp://, file:// etc.
- `duplicado` — repetido entre listas

> Observação: `.com` NUNCA é tratado como extensão (é TLD). Novos gTLDs
> abusados como `.zip` são tratados como extensão — decisão deliberada.

## Variáveis de ambiente

| Var | Default | Uso |
|---|---|---|
| `TRIAGE_CONC` | 100 | threads da triagem |
| `TRIAGE_TIMEOUT` | 12 | timeout por request na triagem (s) |
| `TRIAGE_MAX` | (todos) | limita nº de sites triados (smoke/testes) |
| `CONC` | 60 | threads da análise contextual |
| `CONTEXT_MAX` / `TOTAL_MAX` | 15 / 80 | limites de testes por contexto / total |
| `BEACON_CYCLES` / `BEACON_INTERVAL` | 3 / 3 | beaconing |
| `BS_LISTS` | (15 oficiais) | sobrescreve as listas do Bad Samurai |

Ex.: `TRIAGE_MAX=100 ./agents/scan_v2.sh online saida_teste`

## Validação incluída (2026-09-18)

- Suíte do projeto (`validacao/ea2_unit_test.py`): **71 ok / 0 falhas**
- Suíte do preparador (`validacao/test_prepare_targets.py`): **24 ok / 0 falhas**
- E2E offline + online reais com evidências em `validacao/e2e_offline/` e `validacao/e2e_online/`
- Relatório completo em `validacao/relatorio_v2.1.0.md`